param(
  [string]$AppDir = "",
  [string]$BaseUrl = "http://127.0.0.1:8518",
  [switch]$OpenReport,
  [switch]$Strict
)
$ErrorActionPreference = "Continue"
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
. (Join-Path $ScriptDir "AVS_Package_Common.ps1")
$PackageManifest = Get-AvsPackageManifest (Split-Path -Parent $ScriptDir)
$Version = [string]$PackageManifest.version
Write-Host "[AVS FULL QA] No runtime/UI cache clear will be executed." -ForegroundColor Cyan

function Normalize-PathText([string]$PathText) {
  if ([string]::IsNullOrWhiteSpace($PathText)) { return "" }
  $v = [Environment]::ExpandEnvironmentVariables(([string]$PathText).Trim().Trim('"'))
  try { $v = [System.IO.Path]::GetFullPath($v) } catch {}
  try { if (Test-Path -LiteralPath $v) { $v = (Resolve-Path -LiteralPath $v).Path } } catch {}
  return $v
}
function Read-FirstLineSafe([string]$Path) {
  try { if (Test-Path -LiteralPath $Path) { return (Get-Content -LiteralPath $Path -Encoding UTF8 -ErrorAction Stop | Select-Object -First 1) } } catch {}
  return ""
}
function Test-AvsAppDir([string]$PathText) {
  $v = Normalize-PathText $PathText
  if ([string]::IsNullOrWhiteSpace($v)) { return $false }
  return ((Test-Path -LiteralPath (Join-Path $v "START_AVS.cmd")) -and ((Test-Path -LiteralPath (Join-Path $v "VERSION.txt")) -or (Test-Path -LiteralPath (Join-Path $v "VERSION.json"))))
}
function Add-CandidatePath {
  param([System.Collections.Generic.List[string]]$List,[string]$PathText)
  if (-not [string]::IsNullOrWhiteSpace($PathText)) { [void]$List.Add($PathText) }
}
function Add-ChildCandidate {
  param([System.Collections.Generic.List[string]]$List,[string]$Root,[string]$Child)
  if (-not [string]::IsNullOrWhiteSpace($Root)) {
    try { Add-CandidatePath $List (Join-Path $Root $Child) } catch {}
  }
}
function Resolve-AvsAppDir([string]$InputDir) {
  $candidates = New-Object System.Collections.Generic.List[string]
  $packageRoot = ""
  try {
    if (-not [string]::IsNullOrWhiteSpace($ScriptDir)) { $packageRoot = (Split-Path -Parent $ScriptDir) }
  } catch { $packageRoot = "" }
  Add-CandidatePath $candidates $InputDir
  Add-ChildCandidate $candidates $InputDir "AVS_APP"
  Add-CandidatePath $candidates $packageRoot
  Add-ChildCandidate $candidates $packageRoot "AVS_APP"
  foreach ($root in @($InputDir, $packageRoot, $PackageManifest.default_install_root)) {
    if ([string]::IsNullOrWhiteSpace($root)) { continue }
    $line = Read-FirstLineSafe (Join-Path $root "installed_path.txt")
    if (-not [string]::IsNullOrWhiteSpace($line)) { Add-CandidatePath $candidates $line }
    Add-ChildCandidate $candidates $root "AVS_APP"
  }
  foreach ($c in $candidates) {
    $v = Normalize-PathText $c
    if (Test-AvsAppDir $v) { return $v }
  }
  return (Normalize-PathText $InputDir)
}

if ([string]::IsNullOrWhiteSpace($AppDir)) { $AppDir = (Get-Location).Path }
$OriginalAppDir = $AppDir
$AppDir = Resolve-AvsAppDir $AppDir
if (-not (Test-AvsAppDir $AppDir)) {
  Write-Host "[AVS][ERROR] AVS_APP could not be resolved. Input=$OriginalAppDir, Resolved=$AppDir" -ForegroundColor Red
  Write-Host "[AVS][ACTION] Run 1. Install or Update, then run this menu again from the current package." -ForegroundColor Yellow
  exit 6
}
Write-Host "[AVS FULL QA] Resolved AVS_APP: $AppDir" -ForegroundColor DarkGray
$Stamp = Get-Date -Format "yyyyMMdd_HHmmss"

# full_qa_appdir_resolution_guard: Full QA must operate on installed AVS_APP, never on the extracted package root.
if (-not (Test-Path -LiteralPath (Join-Path $AppDir "tools\self_check"))) {
  Write-Host "[AVS FULL QA][ERROR] Resolved AVS_APP does not contain tools\self_check: $AppDir" -ForegroundColor Red
  Write-Host "[AVS FULL QA][ACTION] Run Install or Update from this package. If installed, delete stale installed_path.txt and reinstall." -ForegroundColor Yellow
  exit 6
}
$FullDir = Join-Path $AppDir "full_qa_reports"
$RunDir = Join-Path $FullDir "AVS_FULL_QA_REPORT_$Stamp"
New-Item -ItemType Directory -Force -Path $RunDir | Out-Null
$summary = New-Object System.Collections.Generic.List[object]
function Read-JsonSafe([string]$Path) {
  try { if (Test-Path -LiteralPath $Path) { return (Get-Content -LiteralPath $Path -Raw -Encoding UTF8 | ConvertFrom-Json) } } catch {}
  return $null
}
function Latest-Json([string]$Folder, [string]$Pattern) {
  if (!(Test-Path -LiteralPath $Folder)) { return $null }
  return Get-ChildItem -LiteralPath $Folder -Filter $Pattern -File -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending | Select-Object -First 1
}
function Get-ReportCounts([string]$Kind) {
  if ($Kind -eq "self") {
    $latest = Latest-Json (Join-Path $AppDir "self_check_reports") "AVS_SELF_CHECK_REPORT_*.json"
    if (!$latest) { return $null }
    $j = Read-JsonSafe $latest.FullName
    if (!$j) { return $null }
    $findings=@(); try { $findings=@($j.analysis.findings) } catch {}
    $fail=@($findings | Where-Object { $_.level -eq "FAIL" }).Count
    $warn=@($findings | Where-Object { $_.level -eq "WARN" }).Count
    $pass=@($findings | Where-Object { $_.level -eq "PASS" }).Count
    return [pscustomobject]@{path=$latest.FullName; fail=$fail; warn=$warn; pass=$pass; info=0; judgement=$(if($fail -gt 0){"NO-GO"}elseif($warn -gt 0){"REVIEW"}else{"GO-CANDIDATE"})}
  }
  if ($Kind -eq "scenario") { $folder="scenario_test_reports"; $pat="AVS_SCENARIO_TEST_REPORT_*.json" }
  elseif ($Kind -eq "ui") { $folder="ui_e2e_reports"; $pat="AVS_UI_E2E_REPORT_*.json" }
  else { return $null }
  $latest = Latest-Json (Join-Path $AppDir $folder) $pat
  if (!$latest) { return $null }
  $j = Read-JsonSafe $latest.FullName
  if (!$j) { return $null }
  return [pscustomobject]@{path=$latest.FullName; fail=[int]$j.fail; warn=[int]$j.warn; pass=[int]$j.pass; info=[int]$j.info; judgement=[string]$j.release_judgement}
}

function Mask-SensitiveObject($Obj) {
  if ($null -eq $Obj) { return $null }
  if ($Obj -is [System.Collections.IDictionary]) {
    $out = [ordered]@{}
    foreach ($k in $Obj.Keys) {
      if ([string]$k -match '(secret|token|authorization|app_secret|api_secret|password|passwd|account_no|account_number|app_key|api_key|license_key|chat_id)') { $out[$k] = if ($null -eq $Obj[$k] -or [string]$Obj[$k] -eq '') { $Obj[$k] } else { '***MASKED***' } }
      else { $out[$k] = Mask-SensitiveObject $Obj[$k] }
    }
    return $out
  }
  if ($Obj -is [array]) { return @($Obj | ForEach-Object { Mask-SensitiveObject $_ }) }
  if ($Obj -is [pscustomobject]) {
    $out = [ordered]@{}
    foreach ($p in $Obj.PSObject.Properties) {
      if ($p.Name -match '(secret|token|authorization|app_secret|api_secret|password|passwd|account_no|account_number|app_key|api_key|license_key|chat_id)') { $out[$p.Name] = if ($null -eq $p.Value -or [string]$p.Value -eq '') { $p.Value } else { '***MASKED***' } }
      else { $out[$p.Name] = Mask-SensitiveObject $p.Value }
    }
    return [pscustomobject]$out
  }
  if ($Obj -is [string]) {
    return ([regex]::Replace($Obj, '(?i)(token=)[^\s,]+', '$1***MASKED***'))
  }
  return $Obj
}
function Copy-RedactedArtifact([string]$Src,[string]$Dst) {
  try {
    if ($Src.ToLower().EndsWith('.json')) {
      $j = Get-Content -LiteralPath $Src -Raw -Encoding UTF8 | ConvertFrom-Json
      $m = Mask-SensitiveObject $j
      $m | ConvertTo-Json -Depth 30 | Set-Content -Path $Dst -Encoding UTF8
    } else {
      $txt = Get-Content -LiteralPath $Src -Raw -Encoding UTF8 -ErrorAction SilentlyContinue
      $txt = [regex]::Replace($txt, '(?i)(api[_-]?key|app[_-]?key|api[_-]?secret|secret[_-]?key|app[_-]?secret|access[_-]?token|refresh[_-]?token|account[_-]?no|account[_-]?number)\s*[:=]\s*[^,\s]+', '$1=***MASKED***')
      Set-Content -Path $Dst -Encoding UTF8 -Value $txt
    }
  } catch {
    Set-Content -Path $Dst -Encoding UTF8 -Value '[redaction_failed]'
  }
}

function Classify-Step([int]$RawExit, $Counts) {
  if (!$Counts) {
    if ($RawExit -eq 0) { return "PASS" }
    return "CRASH"
  }
  if ([int]$Counts.fail -gt 0) { return "FAIL" }
  if ([int]$Counts.warn -gt 0) { return "WARN" }
  if ($RawExit -notin @(0,2)) { return "PASS_EXIT_MISMATCH" }
  return "PASS"
}
function Run-Step {
  param(
    [Parameter(Mandatory=$true)][string]$Name,
    [Parameter(Mandatory=$true)][string]$Script,
    [string[]]$ScriptArgs = @(),
    [Parameter(Mandatory=$true)][string]$Kind
  )
  Write-Host "[AVS FULL QA] $Name" -ForegroundColor Cyan
  $scriptPath = Join-Path $ScriptDir $Script
  if (!(Test-Path -LiteralPath $scriptPath)) {
    $summary.Add([pscustomobject]@{name=$Name; raw_exit_code=999; status="MISSING"; fail=$null; warn=$null; pass=$null; info=$null; report=""; script=$scriptPath}) | Out-Null
    return
  }
  & powershell.exe -NoProfile -ExecutionPolicy Bypass -File $scriptPath @ScriptArgs
  $rawEc = $LASTEXITCODE
  $counts = Get-ReportCounts $Kind
  $status = Classify-Step $rawEc $counts
  if ($counts) {
    $summary.Add([pscustomobject]@{name=$Name; raw_exit_code=$rawEc; status=$status; fail=$counts.fail; warn=$counts.warn; pass=$counts.pass; info=$counts.info; judgement=$counts.judgement; report=$counts.path; script=$scriptPath}) | Out-Null
  } else {
    $summary.Add([pscustomobject]@{name=$Name; raw_exit_code=$rawEc; status=$status; fail=$null; warn=$null; pass=$null; info=$null; judgement=""; report=""; script=$scriptPath}) | Out-Null
  }
}
Run-Step -Name "Self Check" -Script "AVS_Self_Check.ps1" -ScriptArgs @("-AppDir", $AppDir) -Kind "self"
Run-Step -Name "Scenario Test" -Script "AVS_Scenario_Test_Runner.ps1" -ScriptArgs @("-AppDir", $AppDir, "-BaseUrl", $BaseUrl) -Kind "scenario"
Run-Step -Name "UI/E2E QA" -Script "AVS_UI_E2E_Test_Runner.ps1" -ScriptArgs @("-AppDir", $AppDir, "-BaseUrl", $BaseUrl) -Kind "ui"
foreach ($folder in @("self_check_reports","scenario_test_reports","ui_e2e_reports")) {
  $src = Join-Path $AppDir $folder
  $dst = Join-Path $RunDir $folder
  New-Item -ItemType Directory -Force -Path $dst | Out-Null
  if (Test-Path -LiteralPath $src) {
    Get-ChildItem -LiteralPath $src -File -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending | Select-Object -First 8 | ForEach-Object { Copy-Item $_.FullName (Join-Path $dst $_.Name) -Force -ErrorAction SilentlyContinue }
    $ss = Join-Path $src "screenshots"
    if (Test-Path -LiteralPath $ss) { Copy-Item $ss (Join-Path $dst "screenshots") -Recurse -Force -ErrorAction SilentlyContinue }
  }
}
foreach ($rel in @("VERSION.txt","runtime\service_state.json","runtime\ai_execution_status.json","runtime\operation_timeline.json","runtime\auto_trade_status.json","runtime\api_connection_status.json","app_settings.json")) {
  $src = Join-Path $AppDir $rel
  if (Test-Path -LiteralPath $src) {
    $flat = $rel -replace '[\\/:*?"<>|]','_'
    if ($rel -match 'app_settings|api_connection|auto_trade_status|ai_execution_status|service_state|operation_timeline') {
      Copy-RedactedArtifact $src (Join-Path $RunDir ("redacted_" + $flat))
    } else {
      Copy-Item $src (Join-Path $RunDir $flat) -Force -ErrorAction SilentlyContinue
    }
  }
}
$totalFail = 0; $totalWarn = 0; $totalPass = 0; $totalInfo = 0
foreach ($s in $summary) {
  if ($s.fail -ne $null) { $totalFail += [int]$s.fail }
  if ($s.warn -ne $null) { $totalWarn += [int]$s.warn }
  if ($s.pass -ne $null) { $totalPass += [int]$s.pass }
  if ($s.info -ne $null) { $totalInfo += [int]$s.info }
  if ($s.status -in @("CRASH","MISSING")) { $totalFail += 1 }
}
$overall = if (($summary | Where-Object { $_.status -in @("FAIL","CRASH","MISSING") }).Count -gt 0) { "NO-GO" } elseif (($summary | Where-Object { $_.status -eq "WARN" }).Count -gt 0) { "REVIEW" } else { "GO-CANDIDATE" }
$summaryPath = Join-Path $RunDir "full_qa_summary.json"
[pscustomobject]@{tool="AVS Full QA Runner"; version=$Version; generated_at=(Get-Date -Format "yyyy-MM-dd HH:mm:ss"); app_dir=$AppDir; base_url=$BaseUrl; overall=$overall; fail=$totalFail; warn=$totalWarn; pass=$totalPass; info=$totalInfo; steps=$summary} | ConvertTo-Json -Depth 10 | Set-Content -Path $summaryPath -Encoding UTF8
$mdPath = Join-Path $RunDir "full_qa_summary.md"
$lines = New-Object System.Collections.Generic.List[string]
[void]$lines.Add(("# AVS Full QA Report v{0}" -f $Version))
[void]$lines.Add("")
[void]$lines.Add(("- Generated: {0}" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss')))
[void]$lines.Add(("- AVS_APP: {0}" -f $AppDir))
[void]$lines.Add(("- Overall: **{0}**" -f $overall))
[void]$lines.Add(("- Result: FAIL {0} / WARN {1} / PASS {2} / INFO {3}" -f $totalFail,$totalWarn,$totalPass,$totalInfo))
[void]$lines.Add("")
[void]$lines.Add('| Step | Status | FAIL | WARN | PASS | INFO | Raw Exit | Report |')
[void]$lines.Add('|---|---:|---:|---:|---:|---:|---:|---|')
foreach ($s in $summary) {
  $rep = if ($s.report) { Split-Path -Leaf $s.report } else { "" }
  [void]$lines.Add(("| {0} | {1} | {2} | {3} | {4} | {5} | {6} | {7} |" -f $s.name,$s.status,$s.fail,$s.warn,$s.pass,$s.info,$s.raw_exit_code,$rep))
}
$lines | Set-Content -Path $mdPath -Encoding UTF8
$zip = Join-Path $FullDir "AVS_FULL_QA_RESULT_$Stamp.zip"
if (Test-Path -LiteralPath $zip) { Remove-Item $zip -Force -ErrorAction SilentlyContinue }

$uploadNote = Join-Path $RunDir "UPLOAD_ONLY_THIS_FULL_QA_ZIP.txt"
@"
Upload only this Full QA result ZIP for normal verification.
ZIP: $zip
If this ZIP is not created, run Self Check, Scenario Test, and UI/E2E Test individually.
"@ | Set-Content -Path $uploadNote -Encoding UTF8

Compress-Archive -Path (Join-Path $RunDir "*") -DestinationPath $zip -Force
$latestZip = Join-Path $FullDir "AVS_FULL_QA_RESULT_LATEST.zip"
Copy-Item -LiteralPath $zip -Destination $latestZip -Force -ErrorAction SilentlyContinue
Write-Host "[AVS FULL QA] Overall: $overall" -ForegroundColor Green
Write-Host "[AVS FULL QA] Result: FAIL $totalFail / WARN $totalWarn / PASS $totalPass / INFO $totalInfo" -ForegroundColor Green
Write-Host "[AVS FULL QA] Report folder: $RunDir" -ForegroundColor Green
Write-Host "[AVS FULL QA] FINAL RESULT ZIP: $zip" -ForegroundColor Green
Write-Host "[AVS FULL QA] Upload/share this ZIP only. Individual reports are already included inside it." -ForegroundColor Yellow
if ($OpenReport -and (Test-Path -LiteralPath $FullDir)) { Start-Process $FullDir }
if ($overall -eq "NO-GO") { exit 1 }
if ($overall -eq "REVIEW") { exit 2 }
exit 0















