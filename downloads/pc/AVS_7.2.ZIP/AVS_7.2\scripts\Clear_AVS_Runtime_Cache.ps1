param(
  [string]$AppDir = ""
)
$ErrorActionPreference = "Stop"
$ScriptDir = if ([string]::IsNullOrWhiteSpace($PSScriptRoot)) { Split-Path -Parent $MyInvocation.MyCommand.Path } else { $PSScriptRoot }
. (Join-Path $ScriptDir "AVS_Package_Common.ps1")
$PackageManifest = Get-AvsPackageManifest (Split-Path -Parent $ScriptDir)
$Version = [string]$PackageManifest.version
function Log($m){ Write-Host "[AVS Cache Clear] $m" }
if ([string]::IsNullOrWhiteSpace($AppDir)) {
  $Marker = Join-Path (Split-Path -Parent $PSScriptRoot) "installed_path.txt"
  if (Test-Path $Marker) { $AppDir = (Get-Content $Marker -ErrorAction SilentlyContinue | Select-Object -First 1) }
}
if ([string]::IsNullOrWhiteSpace($AppDir)) {
  $Candidate = Join-Path (Split-Path -Parent $PSScriptRoot) "AVS_APP"
  if (Test-Path $Candidate) { $AppDir = $Candidate }
}
if ([string]::IsNullOrWhiteSpace($AppDir) -or !(Test-Path $AppDir)) {
  throw "AVS_APP path was not found. Install or run AVS once first."
}
$AppDir = (Resolve-Path $AppDir).Path
Log "APPDIR=$AppDir"
# Try to stop local AVS cleanly if the stop script exists. This avoids stale UI runtime files.
$StopCmd = Join-Path $AppDir "STOP_AVS.cmd"
if (Test-Path $StopCmd) {
  Log "Stopping AVS before clearing runtime/UI cache..."
  cmd.exe /c "`"$StopCmd`"" | Out-Null
  Start-Sleep -Seconds 2
}
$Deleted = New-Object System.Collections.Generic.List[string]
function Remove-SafePath($p){
  if ([string]::IsNullOrWhiteSpace($p)) { return }
  if (!(Test-Path $p)) { return }
  $rp = (Resolve-Path $p).Path
  if (!$rp.StartsWith($AppDir, [System.StringComparison]::OrdinalIgnoreCase)) { return }
  # Never remove runtime python, venv, source bytecode modules, user settings, license, portfolio or logs.
  if ($rp -match '\\runtime\\python(\\|$)' -or $rp -match '\\.venv(\\|$)' -or $rp -match '\\portfolio(\\|$)' -or $rp -match '\\logs(\\|$)' -or $rp -match '\\decision_cache(\\|$)') { return }
  Remove-Item -LiteralPath $rp -Recurse -Force -ErrorAction SilentlyContinue
  $Deleted.Add($rp) | Out-Null
}
$Runtime = Join-Path $AppDir "runtime"
$Targets = @(
  (Join-Path $Runtime "cache"),
  (Join-Path $Runtime "ui_cache"),
  (Join-Path $Runtime "frontend_cache"),
  (Join-Path $Runtime "browser_cache"),
  (Join-Path $Runtime "api_response_cache"),
  (Join-Path $Runtime "tmp"),
  (Join-Path $AppDir "cache"),
  (Join-Path $AppDir ".cache"),
  (Join-Path $AppDir "tmp"),
  (Join-Path $AppDir "assets\cache")
)
foreach($t in $Targets){ Remove-SafePath $t }
# Remove only known UI/runtime marker JSON files, not Python bytecode or account/license/settings files.
$Patterns = @(
  "ui_runtime*.json",
  "frontend_runtime*.json",
  "frontend_bundle_cache*.json",
  "asset_manifest_cache*.json",
  "dashboard_snapshot_cache*.json",
  "market_snapshot_cache*.json",
  "hot_issues_cache*.json",
  "web_runtime*.json",
  "cache_bust*.json"
)
foreach($pat in $Patterns){
  Get-ChildItem -LiteralPath $Runtime -Filter $pat -File -ErrorAction SilentlyContinue | ForEach-Object { Remove-SafePath $_.FullName }
}
$Bust = Join-Path $Runtime "cache_bust.json"
@{
  cleared_at = (Get-Date).ToString("yyyy-MM-dd HH:mm:ss")
  version = $Version
  note = "Runtime/UI cache was cleared from AVS.bat menu. Browser hard refresh Ctrl+F5 is still recommended."
} | ConvertTo-Json -Depth 3 | Set-Content -Path $Bust -Encoding UTF8
$Stamp = Join-Path $AppDir "CLEAR_RUNTIME_CACHE_DONE.txt"
"Cleared at $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')`r`nDeleted:`r`n$($Deleted -join "`r`n")" | Set-Content -Path $Stamp -Encoding UTF8
Log "Deleted $($Deleted.Count) cache path(s)."
Log "Done. Run AVS again and press Ctrl+F5 in the browser."















