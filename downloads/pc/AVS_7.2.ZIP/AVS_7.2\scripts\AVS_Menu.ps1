
param([string]$PackageRoot = "")
$ErrorActionPreference = "Continue"
if ([string]::IsNullOrWhiteSpace($PackageRoot)) { $PackageRoot = Split-Path -Parent $MyInvocation.MyCommand.Path | Split-Path -Parent }
$PackageRoot = [Environment]::ExpandEnvironmentVariables($PackageRoot.Trim().Trim('"'))
try { $PackageRoot = (Resolve-Path -LiteralPath $PackageRoot).Path } catch {}
$ScriptDir = Join-Path $PackageRoot "scripts"
. (Join-Path $ScriptDir "AVS_Package_Common.ps1")
$PackageManifest = Get-AvsPackageManifest $PackageRoot
$Version = [string]$PackageManifest.version
$BuildId = [string]$PackageManifest.build_id
$PackageKind = [string]$PackageManifest.package_kind
$DefaultInstallRoot = [string]$PackageManifest.default_install_root
# AVS_MENU_RESOLVE_APPDIR_GUARD_1567
function Resolve-AppDir {
  $candidates = New-Object System.Collections.Generic.List[string]
  foreach ($file in @((Join-Path $PackageRoot "installed_path.txt"),(Join-Path $DefaultInstallRoot "installed_path.txt"))) {
    try { if (Test-Path -LiteralPath $file) { $line = Get-Content -LiteralPath $file -Encoding UTF8 -ErrorAction SilentlyContinue | Select-Object -First 1; if ($line) { [void]$candidates.Add([string]$line) } } } catch {}
  }
  [void]$candidates.Add((Join-Path $DefaultInstallRoot "AVS_APP"))
  [void]$candidates.Add((Join-Path $PackageRoot "AVS_APP"))
  foreach ($c in $candidates) {
    $v = [Environment]::ExpandEnvironmentVariables(([string]$c).Trim().Trim('"'))
    try { $v = [System.IO.Path]::GetFullPath($v) } catch {}
    if ((Test-Path -LiteralPath $v) -and (Test-Path -LiteralPath (Join-Path $v "START_AVS.cmd"))) { return $v }
  }
  return ""
}
function Run-PS {
  param(
    [Parameter(Mandatory=$true,Position=0)][string]$ScriptName,
    [Parameter(Position=1)][string[]]$ScriptArgs = @()
  )
  $script = Join-Path $ScriptDir $ScriptName
  if (!(Test-Path -LiteralPath $script)) {
    Write-Host "[AVS][ERROR] Script not found: $script" -ForegroundColor Red
    return 1
  }
  try {
    # Important: pipe child output to host so assignment like `$ec = Run-PS ...`
    # captures only the numeric exit code, not every log line emitted by the child script.
    & powershell.exe -NoProfile -ExecutionPolicy Bypass -File $script @ScriptArgs | Out-Host
    $code = $LASTEXITCODE
    if ($null -eq $code) { $code = 0 }
    return [int]$code
  } catch {
    Write-Host "[AVS][ERROR] Failed to execute $ScriptName : $($_.Exception.Message)" -ForegroundColor Red
    return 9001
  }
}
function Ensure-AppDir {
  $app = Resolve-AppDir
  if ([string]::IsNullOrWhiteSpace($app)) {
    Write-Host ""; Write-Host "[AVS][ERROR] Installed AVS_APP was not found." -ForegroundColor Red
    Write-Host "Select 1. Install or Patch/Update first."
    return ""
  }
  return $app
}
function Pause-Menu { Write-Host ""; Read-Host "Press Enter to continue" | Out-Null }
while ($true) {
  Clear-Host
  Write-Host "Alpha Viper System $Version $PackageKind"
  Write-Host ""
  Write-Host "1. Install or Patch/Update"
  Write-Host "2. Run AVS"
  Write-Host "3. Uninstall"
  Write-Host "4. Kill stale AVS server"
  Write-Host "5. Runtime Repair and Run (clears runtime/UI cache)"
  Write-Host "6. Clear Runtime/UI Cache"
  Write-Host "7. Self Check and Log Report"
  Write-Host "8. Scenario Test Runner"
  Write-Host "9. UI/E2E Test Runner"
  Write-Host "A. Full QA Runner (single result ZIP, no cache clear)"
  Write-Host "0. Exit"
  $app = Resolve-AppDir
  if ($app) { Write-Host ""; Write-Host "Current install path: $app" -ForegroundColor DarkGray }
  Write-Host ""
  $sel = (Read-Host "Select").Trim().ToUpperInvariant()
  if ($sel -eq "0") { exit 0 }
  if ($sel -eq "1") {
    Write-Host ""; Write-Host "Enter AVS install path. Default: $DefaultInstallRoot"
    $target = Read-Host "Install path"
    if ([string]::IsNullOrWhiteSpace($target)) { $target = $DefaultInstallRoot }
    $ec = Run-PS -ScriptName "Install_AVS.ps1" -ScriptArgs @("-InstallRoot", $target)
    if ($ec -ne 0) { Write-Host "[AVS][ERROR] Command failed with exit code $ec" -ForegroundColor Red }
    Pause-Menu; continue
  }
  if ($sel -eq "2") {
    $app = Ensure-AppDir; if (!$app) { Pause-Menu; continue }
    $ec = Run-PS -ScriptName "Kill_Stale_AVS_Server.ps1" -ScriptArgs @("-AppDir", $app, "-ExpectedVersion", $Version, "-ExpectedBuildId", $BuildId)
    if ($ec -ne 0) { Write-Host "[AVS][ERROR] Stale guard failed with exit code $ec" -ForegroundColor Red; Pause-Menu; continue }
    & (Join-Path $app "START_AVS.cmd")
    Pause-Menu; continue
  }
  if ($sel -eq "3") {
    $installRoot=$DefaultInstallRoot; $app=Resolve-AppDir; if($app){ try { $installRoot=(Split-Path -Parent $app) } catch {} }
    $ec=Run-PS -ScriptName "Uninstall_AVS.ps1" -ScriptArgs @("-InstallRoot", $installRoot)
    if($ec -ne 0){Write-Host "[AVS][ERROR] Command failed with exit code $ec" -ForegroundColor Red}
    Pause-Menu; continue
  }
  if ($sel -eq "4") {
    $app=Resolve-AppDir; if(!$app){ $app=Join-Path $DefaultInstallRoot "AVS_APP" }
    $ec=Run-PS -ScriptName "Kill_Stale_AVS_Server.ps1" -ScriptArgs @("-AppDir", $app, "-ExpectedVersion", $Version, "-ExpectedBuildId", $BuildId, "-Force", "-AlsoKillLegacyUi")
    if($ec -ne 0){Write-Host "[AVS][ERROR] Command failed with exit code $ec" -ForegroundColor Red}
    Pause-Menu; continue
  }
  if ($sel -eq "5") {
    $app=Ensure-AppDir; if($app){
      $ec=Run-PS -ScriptName "Kill_Stale_AVS_Server.ps1" -ScriptArgs @("-AppDir", $app, "-ExpectedVersion", $Version, "-ExpectedBuildId", $BuildId, "-Force", "-AlsoKillLegacyUi")
      if($ec -eq 0){ $ec=Run-PS -ScriptName "Clear_AVS_Runtime_Cache.ps1" -ScriptArgs @("-AppDir", $app) }
      if($ec -eq 0){ & (Join-Path $app "START_AVS.cmd") } else { Write-Host "[AVS][ERROR] Command failed with exit code $ec" -ForegroundColor Red }
    }
    Pause-Menu; continue
  }
  if ($sel -eq "6") {
    $app=Ensure-AppDir; if($app){ $ec=Run-PS -ScriptName "Clear_AVS_Runtime_Cache.ps1" -ScriptArgs @("-AppDir", $app); if($ec -ne 0){Write-Host "[AVS][ERROR] Command failed with exit code $ec" -ForegroundColor Red} }
    Pause-Menu; continue
  }
  if ($sel -eq "7") {
    $app=Ensure-AppDir; if($app){ Write-Host "[AVS SELF CHECK] Scenario Test is NOT executed from this menu."; $ec=Run-PS -ScriptName "AVS_Self_Check.ps1" -ScriptArgs @("-AppDir", $app); if($ec -eq 2){Write-Host "[AVS][CHECK] Self Check completed with warnings." -ForegroundColor Yellow} elseif($ec -ne 0){Write-Host "[AVS][ERROR] Command failed with exit code $ec" -ForegroundColor Red} }
    Pause-Menu; continue
  }
  if ($sel -eq "8") {
    $app=Ensure-AppDir; if($app){ $ec=Run-PS -ScriptName "AVS_Scenario_Test_Runner.ps1" -ScriptArgs @("-AppDir", $app); if($ec -eq 2){Write-Host "[AVS][CHECK] Scenario Test completed with issues." -ForegroundColor Yellow} elseif($ec -ne 0){Write-Host "[AVS][ERROR] Command failed with exit code $ec" -ForegroundColor Red} }
    Pause-Menu; continue
  }
  if ($sel -eq "9") {
    $app=Ensure-AppDir; if($app){ $ec=Run-PS -ScriptName "AVS_UI_E2E_Test_Runner.ps1" -ScriptArgs @("-AppDir", $app); if($ec -eq 2){Write-Host "[AVS][CHECK] UI/E2E QA completed with issues." -ForegroundColor Yellow} elseif($ec -ne 0){Write-Host "[AVS][ERROR] Command failed with exit code $ec" -ForegroundColor Red} }
    Pause-Menu; continue
  }
  if ($sel -eq "A") {
    $app=Ensure-AppDir; if($app){
      Write-Host "[AVS FULL QA] No runtime/UI cache clear is executed by this menu." -ForegroundColor Cyan
      Write-Host "[AVS FULL QA] AppDir: $app" -ForegroundColor DarkGray
      Write-Host "[AVS FULL QA] Upload/share only the final AVS_FULL_QA_RESULT_*.zip file unless Full QA cannot run." -ForegroundColor Yellow
      $ec=Run-PS -ScriptName "AVS_Full_QA_Runner.ps1" -ScriptArgs @("-AppDir", $app)
      if($ec -eq 2){Write-Host "[AVS][CHECK] Full QA completed with issues. Upload only the final Full QA ZIP." -ForegroundColor Yellow} elseif($ec -ne 0){Write-Host "[AVS][ERROR] Command failed with exit code $ec. If Full QA did not produce a ZIP, run menus 7, 8, and 9 individually." -ForegroundColor Red}
    }
    Pause-Menu; continue
  }
  Write-Host "Invalid selection." -ForegroundColor Yellow; Pause-Menu
}















