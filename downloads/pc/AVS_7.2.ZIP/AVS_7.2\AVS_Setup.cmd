@echo off
start "" "%~dp0AVS_Setup.exe" %*







