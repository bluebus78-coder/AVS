@echo off
chcp 65001 >nul
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\AVS_Menu.ps1" -PackageRoot "%~dp0"
set "EC=%ERRORLEVEL%"
if not "%EC%"=="0" (
  echo.
  echo [AVS][ERROR] Menu exited with code %EC%.
  pause
)
exit /b %EC%








