param(
  [string]$AppDir = "",
  [string]$BaseUrl = "http://127.0.0.1:8518",
  [switch]$OpenReport,
  [switch]$RequireBrowser
)
$ErrorActionPreference = "Stop"
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
. (Join-Path $ScriptDir "AVS_Package_Common.ps1")
$PackageManifest = Get-AvsPackageManifest (Split-Path -Parent $ScriptDir)
$Version = [string]$PackageManifest.version
function Read-FirstLine([string]$Path) {
  try { if (Test-Path -LiteralPath $Path) { return (Get-Content -LiteralPath $Path -Encoding UTF8 -ErrorAction Stop | Select-Object -First 1) } } catch {}
  return ""
}
function Resolve-Python([string]$Root) {
  $candidates = @()
  $pp = Join-Path $Root "python_path.txt"
  $line = Read-FirstLine $pp
  if (-not [string]::IsNullOrWhiteSpace($line)) { $candidates += $line.Trim().Trim('"') }
  $candidates += @(Join-Path $Root "runtime\python\Scripts\python.exe")
  $candidates += @(Join-Path $Root "runtime\python\python.exe")
  $candidates += @(Join-Path $Root ".venv\Scripts\python.exe")
  foreach ($py in $candidates) { try { if ($py -and (Test-Path -LiteralPath $py)) { return $py } } catch {} }
  return ""
}
function Get-FlatReportCounts([string]$Root) {
  $dir = Join-Path $Root "ui_e2e_reports"
  if (!(Test-Path -LiteralPath $dir)) { return $null }
  $latest = Get-ChildItem -LiteralPath $dir -Filter "AVS_UI_E2E_REPORT_*.json" -File -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending | Select-Object -First 1
  if (!$latest) { return $null }
  try { $j = Get-Content -LiteralPath $latest.FullName -Raw -Encoding UTF8 | ConvertFrom-Json } catch { return $null }
  return [pscustomobject]@{path=$latest.FullName; fail=[int]$j.fail; warn=[int]$j.warn; pass=[int]$j.pass; status=$(if([int]$j.fail -gt 0){"FAIL"}elseif([int]$j.warn -gt 0){"WARN"}else{"PASS"})}
}

function Normalize-PathText([string]$PathText) {
  if ([string]::IsNullOrWhiteSpace($PathText)) { return "" }
  $v = [Environment]::ExpandEnvironmentVariables(([string]$PathText).Trim().Trim('"'))
  try { $v = [System.IO.Path]::GetFullPath($v) } catch {}
  try { if (Test-Path -LiteralPath $v) { $v = (Resolve-Path -LiteralPath $v).Path } } catch {}
  return $v
}
function Read-FirstLineSafe([string]$Path) {
  try { if (Test-Path -LiteralPath $Path) { return (Get-Content -LiteralPath $Path -Encoding UTF8 -ErrorAction Stop | Select-Object -First 1) } } catch {}
  return ""
}
function Test-AvsAppDir([string]$PathText) {
  $v = Normalize-PathText $PathText
  if ([string]::IsNullOrWhiteSpace($v)) { return $false }
  return ((Test-Path -LiteralPath (Join-Path $v "START_AVS.cmd")) -and ((Test-Path -LiteralPath (Join-Path $v "VERSION.txt")) -or (Test-Path -LiteralPath (Join-Path $v "VERSION.json"))))
}
function Add-CandidatePath {
  param([System.Collections.Generic.List[string]]$List,[string]$PathText)
  if (-not [string]::IsNullOrWhiteSpace($PathText)) { [void]$List.Add($PathText) }
}
function Add-ChildCandidate {
  param([System.Collections.Generic.List[string]]$List,[string]$Root,[string]$Child)
  if (-not [string]::IsNullOrWhiteSpace($Root)) {
    try { Add-CandidatePath $List (Join-Path $Root $Child) } catch {}
  }
}
function Resolve-AvsAppDir([string]$InputDir) {
  $candidates = New-Object System.Collections.Generic.List[string]
  $packageRoot = ""
  try {
    if (-not [string]::IsNullOrWhiteSpace($ScriptDir)) { $packageRoot = (Split-Path -Parent $ScriptDir) }
  } catch { $packageRoot = "" }
  Add-CandidatePath $candidates $InputDir
  Add-ChildCandidate $candidates $InputDir "AVS_APP"
  Add-CandidatePath $candidates $packageRoot
  Add-ChildCandidate $candidates $packageRoot "AVS_APP"
  foreach ($root in @($InputDir, $packageRoot, $PackageManifest.default_install_root)) {
    if ([string]::IsNullOrWhiteSpace($root)) { continue }
    $line = Read-FirstLineSafe (Join-Path $root "installed_path.txt")
    if (-not [string]::IsNullOrWhiteSpace($line)) { Add-CandidatePath $candidates $line }
    Add-ChildCandidate $candidates $root "AVS_APP"
  }
  foreach ($c in $candidates) {
    $v = Normalize-PathText $c
    if (Test-AvsAppDir $v) { return $v }
  }
  return (Normalize-PathText $InputDir)
}

if ([string]::IsNullOrWhiteSpace($AppDir)) { $AppDir = (Get-Location).Path }
$OriginalAppDir = $AppDir
$AppDir = Resolve-AvsAppDir $AppDir
if (-not (Test-AvsAppDir $AppDir)) {
  Write-Host "[AVS][ERROR] AVS_APP could not be resolved. Input=$OriginalAppDir, Resolved=$AppDir" -ForegroundColor Red
  Write-Host "[AVS][ACTION] Run 1. Install or Update, then run this menu again from the current package." -ForegroundColor Yellow
  exit 6
}
Write-Host "[AVS UI/E2E] Resolved AVS_APP: $AppDir" -ForegroundColor DarkGray
$AppVersion = Read-FirstLine (Join-Path $AppDir "VERSION.txt")
if (-not [string]::IsNullOrWhiteSpace($AppVersion) -and $AppVersion -ne $Version) {
  Write-Host "[AVS UI/E2E][ERROR] Installed AVS_APP version mismatch." -ForegroundColor Red
  Write-Host "[AVS UI/E2E][ERROR] APP=$AppVersion, runner=$Version" -ForegroundColor Red
  Write-Host "[AVS UI/E2E][ACTION] Run Install or Update from the current package." -ForegroundColor Yellow
  exit 5
}
$ToolCandidates = @(
  (Join-Path $AppDir "tools\ui_e2e\avs_ui_e2e.py"),
  (Join-Path $AppDir "tools\ui_e2e\avs_ui_e2e.pyc")
)
$Tool = ""
foreach ($t in $ToolCandidates) { if (Test-Path -LiteralPath $t) { $Tool = $t; break } }
if ([string]::IsNullOrWhiteSpace($Tool)) { throw "UI/E2E QA tool not found under $AppDir\tools\ui_e2e" }
$Py = Resolve-Python $AppDir
if ([string]::IsNullOrWhiteSpace($Py)) { throw "Local AVS Python runtime not found under $AppDir" }
Write-Host "[AVS UI/E2E] v$Version" -ForegroundColor Cyan
Write-Host "[AVS UI/E2E] APPDIR=$AppDir"
Write-Host "[AVS UI/E2E] TOOL=$Tool"
Write-Host "[AVS UI/E2E] PYTHON=$Py"
$args = @($Tool, "--app", $AppDir, "--base-url", $BaseUrl)
if ($RequireBrowser) { $args += "--require-browser" }
& $Py @args
$rawEc = $LASTEXITCODE
$ReportDir = Join-Path $AppDir "ui_e2e_reports"
Write-Host "[AVS UI/E2E] Report folder: $ReportDir"
if ($OpenReport -and (Test-Path -LiteralPath $ReportDir)) { Start-Process $ReportDir }
$counts = Get-FlatReportCounts $AppDir
if ($counts) {
  Write-Host ("[AVS UI/E2E] Classified from report: FAIL {0} / WARN {1} / PASS {2}" -f $counts.fail,$counts.warn,$counts.pass)
  if ($counts.fail -gt 0) { exit 1 }
  if ($counts.warn -gt 0) { exit 2 }
  exit 0
}
if ($rawEc -ne 0) { exit $rawEc }
exit 0















