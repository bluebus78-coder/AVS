param([string]$InstallRoot = "", [ValidateSet("KeepBackup","FullDelete")][string]$Mode = "KeepBackup")
$ErrorActionPreference = "Stop"
try {
  $utf8NoBom = New-Object System.Text.UTF8Encoding($false)
  [Console]::OutputEncoding = $utf8NoBom
  $OutputEncoding = $utf8NoBom
} catch {}
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$PackageRoot = Split-Path -Parent $ScriptDir
. (Join-Path $ScriptDir "AVS_Package_Common.ps1")
$PackageManifest = Get-AvsPackageManifest $PackageRoot
$DefaultInstallRoot = [string]$PackageManifest.default_install_root
if ([string]::IsNullOrWhiteSpace($InstallRoot)) {
  $installedPathFile = Join-Path $PackageRoot "installed_path.txt"
  if (Test-Path $installedPathFile) {
    $appFromFile = (Get-Content $installedPathFile -ErrorAction SilentlyContinue | Select-Object -First 1)
    if ($appFromFile) { $InstallRoot = Split-Path -Parent $appFromFile }
  }
}
if ([string]::IsNullOrWhiteSpace($InstallRoot)) { $InstallRoot = $DefaultInstallRoot }
$InstallRoot = [Environment]::ExpandEnvironmentVariables(([string]$InstallRoot).Trim().Trim('"'))
$AppDir = Join-Path $InstallRoot "AVS_APP"
function Remove-AVSInstallArtifacts([string]$InstallRoot, [string]$AppDir) {
  $runName = "AVS " + (-join ([char[]](0xC2E4,0xD589))) + ".lnk"
  $uninstallName = "AVS " + (-join ([char[]](0xC0AD,0xC81C))) + ".lnk"
  $shortcutDirs = @()
  $desktopDir = [Environment]::GetFolderPath('Desktop')
  if (-not [string]::IsNullOrWhiteSpace($desktopDir)) { $shortcutDirs += $desktopDir }
  $programsDir = [Environment]::GetFolderPath('Programs')
  if (-not [string]::IsNullOrWhiteSpace($programsDir)) { $shortcutDirs += (Join-Path $programsDir "AVS") }
  foreach ($dir in $shortcutDirs) {
    if ([string]::IsNullOrWhiteSpace($dir)) { continue }
    foreach ($name in @($runName, $uninstallName, "AVS 실행.lnk", "AVS 삭제.lnk")) {
      Remove-Item -LiteralPath (Join-Path $dir $name) -Force -ErrorAction SilentlyContinue
    }
  }
  if (-not [string]::IsNullOrWhiteSpace($programsDir)) {
    $startDir = Join-Path $programsDir "AVS"
    try {
      if ((Test-Path -LiteralPath $startDir) -and -not (Get-ChildItem -LiteralPath $startDir -Force -ErrorAction SilentlyContinue | Select-Object -First 1)) {
        Remove-Item -LiteralPath $startDir -Force -ErrorAction SilentlyContinue
      }
    } catch {
    }
  }
  Remove-Item -LiteralPath "HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\Alpha Viper System" -Recurse -Force -ErrorAction SilentlyContinue
}
function Stop-AVSAppDirProcesses([string]$AppDir) {
  if ([string]::IsNullOrWhiteSpace($AppDir)) { return }
  try {
    $needle = $AppDir.TrimEnd('\')
    Get-CimInstance Win32_Process -ErrorAction SilentlyContinue |
      Where-Object {
        ($_.ExecutablePath -and $_.ExecutablePath.StartsWith($needle, [System.StringComparison]::OrdinalIgnoreCase)) -or
        ($_.CommandLine -and $_.CommandLine.IndexOf($needle, [System.StringComparison]::OrdinalIgnoreCase) -ge 0)
      } |
      ForEach-Object {
        try { Stop-Process -Id ([int]$_.ProcessId) -Force -ErrorAction SilentlyContinue } catch {}
      }
  } catch {}
}
Write-Host "Alpha Viper System $($PackageManifest.version) uninstall"
Write-Host "Install root: $InstallRoot"
Write-Host "Mode: $Mode"
if (!(Test-Path $AppDir)) { Remove-AVSInstallArtifacts $InstallRoot $AppDir; Write-Host "AVS_APP not found. Shortcuts and Windows Apps entry were cleaned."; exit 0 }
if ($Mode -ne "FullDelete") {
  $backup = Join-Path $InstallRoot ("AVS_USER_DATA_BACKUP_" + (Get-Date -Format 'yyyyMMdd_HHmmss'))
  New-Item -ItemType Directory -Force -Path $backup | Out-Null
  foreach ($name in 'app_settings.json','license_status.json','avs_license.lic','.env','database','portfolio','decision_cache','backups','logs') {
    $src = Join-Path $AppDir $name
    if (Test-Path $src) { Copy-Item $src (Join-Path $backup $name) -Recurse -Force -ErrorAction SilentlyContinue }
  }
  Write-Host "User data backup: $backup"
}
foreach ($pidFile in @('runtime\html_server.pid','runtime\auto_trade_worker.pid')) {
  $p = Join-Path $AppDir $pidFile
  if (Test-Path $p) { try { $pid = (Get-Content $p -ErrorAction SilentlyContinue | Select-Object -First 1).Trim(); if ($pid) { Stop-Process -Id ([int]$pid) -Force -ErrorAction SilentlyContinue } } catch {} }
}
Stop-AVSAppDirProcesses $AppDir
Remove-Item $AppDir -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item (Join-Path $PackageRoot "installed_path.txt") -Force -ErrorAction SilentlyContinue
Remove-Item (Join-Path $InstallRoot "installed_path.txt") -Force -ErrorAction SilentlyContinue
Remove-AVSInstallArtifacts $InstallRoot $AppDir
Write-Host "Uninstall complete."















