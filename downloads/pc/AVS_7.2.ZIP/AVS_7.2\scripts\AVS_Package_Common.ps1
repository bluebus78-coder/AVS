﻿function Get-AvsPackageRoot {
  param([string]$ScriptDir)
  if ([string]::IsNullOrWhiteSpace($ScriptDir)) {
    $ScriptDir = if ([string]::IsNullOrWhiteSpace($PSScriptRoot)) { (Get-Location).Path } else { $PSScriptRoot }
  }
  return (Split-Path -Parent $ScriptDir)
}

function Get-AvsPackageManifest {
  param([string]$PackageRoot)
  if ([string]::IsNullOrWhiteSpace($PackageRoot)) {
    $PackageRoot = Get-AvsPackageRoot $PSScriptRoot
  }
  $manifestPath = Join-Path $PackageRoot "package_manifest.json"
  $version = ""
  $productName = "Alpha Viper System"
  $packageKind = ""
  if (Test-Path -LiteralPath $manifestPath) {
    try {
      $j = Get-Content -LiteralPath $manifestPath -Raw -Encoding UTF8 | ConvertFrom-Json
      if ($j.product_name) { $productName = [string]$j.product_name }
      if ($j.version) { $version = [string]$j.version }
      if ($j.package_kind) { $packageKind = [string]$j.package_kind }
      $buildId = if ($j.build_id) { [string]$j.build_id } else { $version }
      $defaultRoot = if ($j.default_install_root) { [string]$j.default_install_root } else { "C:\AVS_$version" }
      return [pscustomobject]@{
        product_name = $productName
        version = $version
        build_id = $buildId
        package_kind = $packageKind
        default_install_root = $defaultRoot
        manifest_path = $manifestPath
      }
    } catch {
      throw "Invalid package_manifest.json: $($_.Exception.Message)"
    }
  }
  $folder = Split-Path -Leaf $PackageRoot
  if ($folder -match 'AVS_(\d+\.\d+(?:\.\d+)?)') { $version = $Matches[1] }
  if ([string]::IsNullOrWhiteSpace($version)) { $version = "0.0.0" }
  return [pscustomobject]@{
    product_name = $productName
    version = $version
    build_id = $version
    package_kind = $packageKind
    default_install_root = "C:\AVS_$version"
    manifest_path = ""
  }
}

