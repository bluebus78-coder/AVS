param([string]$InstallRoot = "", [switch]$SkipShortcuts)
$ErrorActionPreference = "Stop"
try {
  $utf8NoBom = New-Object System.Text.UTF8Encoding($false)
  [Console]::OutputEncoding = $utf8NoBom
  $OutputEncoding = $utf8NoBom
} catch {}
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$PackageRoot = Split-Path -Parent $ScriptDir
. (Join-Path $ScriptDir "AVS_Package_Common.ps1")
$PackageManifest = Get-AvsPackageManifest $PackageRoot
$Version = [string]$PackageManifest.version
$ProductName = [string]$PackageManifest.product_name
$DefaultInstallRoot = [string]$PackageManifest.default_install_root
if ([string]::IsNullOrWhiteSpace($InstallRoot)) {
  Write-Host ""
  Write-Host "Enter AVS install path. Press Enter to use the default path."
  Write-Host "Default path: $DefaultInstallRoot"
  $typed = Read-Host "Install path"
  if ([string]::IsNullOrWhiteSpace($typed)) { $InstallRoot = $DefaultInstallRoot } else { $InstallRoot = $typed }
}
$InstallRoot = [Environment]::ExpandEnvironmentVariables(([string]$InstallRoot).Trim().Trim('"'))
if ([string]::IsNullOrWhiteSpace($InstallRoot)) { $InstallRoot = $DefaultInstallRoot }
$PayloadDir = Join-Path $PackageRoot "payload"
$AppDir = Join-Path $InstallRoot "AVS_APP"
$SetupDir = Join-Path $InstallRoot "_setup"
$LogDir = Join-Path $InstallRoot "logs"
New-Item -ItemType Directory -Force -Path $InstallRoot,$SetupDir,$LogDir | Out-Null
$Log = Join-Path $LogDir "install.log"
$PyInstallLog = Join-Path $LogDir "python_installer.log"
function Log([string]$m) { $line = "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') $m"; Write-Host $m; Add-Content -Path $Log -Value $line -Encoding UTF8 }
$sha256 = [Security.Cryptography.SHA256]::Create()
try { $mutexKey = ([BitConverter]::ToString($sha256.ComputeHash([Text.Encoding]::UTF8.GetBytes($InstallRoot.ToLowerInvariant())))).Replace("-", "").Substring(0,16) } finally { $sha256.Dispose() }
$script:InstallMutex = New-Object Threading.Mutex($false, "Local\AVS_Installer_$mutexKey")
if (-not $script:InstallMutex.WaitOne(0)) {
  Log "Another AVS installer is already running for this install path."
  throw "AVS installation is already running. Wait for it to finish and try again."
}
function Normalize-VersionText([string]$v) {
  if ([string]::IsNullOrWhiteSpace($v)) { return "" }
  return (([string]$v).Trim() -replace '[^0-9.]','')
}
function Compare-AvsVersion([string]$Left, [string]$Right) {
  $l = (Normalize-VersionText $Left).Split('.') | Where-Object { $_ -ne "" }
  $r = (Normalize-VersionText $Right).Split('.') | Where-Object { $_ -ne "" }
  $max = [Math]::Max($l.Count, $r.Count)
  for ($i=0; $i -lt $max; $i++) {
    $li = 0; $ri = 0
    if ($i -lt $l.Count) { [void][int]::TryParse($l[$i], [ref]$li) }
    if ($i -lt $r.Count) { [void][int]::TryParse($r[$i], [ref]$ri) }
    if ($li -gt $ri) { return 1 }
    if ($li -lt $ri) { return -1 }
  }
  return 0
}
function Read-InstalledAvsVersion([string]$Root) {
  $versionFile = Join-Path $Root "VERSION.txt"
  if (Test-Path -LiteralPath $versionFile) {
    try { return (Get-Content -LiteralPath $versionFile -Encoding UTF8 -ErrorAction Stop | Select-Object -First 1) } catch {}
  }
  $jsonFile = Join-Path $Root "VERSION.json"
  if (Test-Path -LiteralPath $jsonFile) {
    try {
      $j = Get-Content -LiteralPath $jsonFile -Raw -Encoding UTF8 | ConvertFrom-Json
      if ($j.version) { return [string]$j.version }
      if ($j.app_version) { return [string]$j.app_version }
    } catch {}
  }
  return ""
}
function Write-InstalledAvsVersionState([string]$InstallRoot,[string]$AppDir,[string]$FromVersion,[string]$ToVersion) {
  $state = [ordered]@{
    product = "Alpha Viper System"
    package_kind = "standard"
    previous_version = $FromVersion
    installed_version = $ToVersion
    package_revision = "$ToVersion"
    app_dir = $AppDir
    installed_at = (Get-Date -Format "yyyy-MM-dd HH:mm:ss")
    upgrade_policy = "same-path-preserve-user-data; downgrade-blocked"
  }
  $json = ($state | ConvertTo-Json -Depth 4)
  Set-Content -Path (Join-Path $InstallRoot "installed_version.json") -Value $json -Encoding UTF8 -Force
  Set-Content -Path (Join-Path $AppDir "installed_version.json") -Value $json -Encoding UTF8 -Force
  Add-Content -Path (Join-Path $InstallRoot "version_history.jsonl") -Value ($state | ConvertTo-Json -Compress) -Encoding UTF8
}
function Quote-Arg([string]$s) {
  if ($null -eq $s) { return '""' }
  $v = [string]$s
  if ($v.Length -eq 0) { return '""' }
  if ($v -match '[\s"]') { return '"' + ($v -replace '"','\"') + '"' }
  return $v
}
function Join-Args([object[]]$items) {
  $clean = @()
  foreach ($a in $items) { if ($null -ne $a -and ([string]$a).Length -gt 0) { $clean += (Quote-Arg ([string]$a)) } }
  return ($clean -join ' ')
}
function Get-SafeNativeWorkDir() {
  try {
    if (![string]::IsNullOrWhiteSpace($SetupDir) -and (Test-Path -LiteralPath $SetupDir)) { return $SetupDir }
  } catch {}
  try {
    $tmp = [System.IO.Path]::GetTempPath()
    if (![string]::IsNullOrWhiteSpace($tmp) -and (Test-Path -LiteralPath $tmp)) { return $tmp }
  } catch {}
  return $InstallRoot
}
function Invoke-NativeLogged([string]$Exe, [object[]]$ArgItems, [string]$Name) {
  $stamp = Get-Date -Format 'yyyyMMdd_HHmmss_fff'
  $safe = ($Name -replace '[^A-Za-z0-9_.-]','_')
  $outFile = Join-Path $SetupDir ("native_${safe}_${stamp}.out.log")
  $errFile = Join-Path $SetupDir ("native_${safe}_${stamp}.err.log")
  $argLine = Join-Args $ArgItems
  $workDir = Get-SafeNativeWorkDir
  try {
    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName = $Exe
    $psi.Arguments = $argLine
    $psi.WorkingDirectory = $workDir
    $psi.UseShellExecute = $false
    $psi.CreateNoWindow = $true
    $psi.RedirectStandardOutput = $true
    $psi.RedirectStandardError = $true
    $p = [System.Diagnostics.Process]::Start($psi)
    $stdout = $p.StandardOutput.ReadToEnd()
    $stderr = $p.StandardError.ReadToEnd()
    $p.WaitForExit()
    if ($stdout) { Set-Content -Path $outFile -Value $stdout -Encoding UTF8; Add-Content -Path $Log -Value $stdout -Encoding UTF8 }
    if ($stderr) { Set-Content -Path $errFile -Value $stderr -Encoding UTF8; Add-Content -Path $Log -Value $stderr -Encoding UTF8 }
    Log "$Name exit code: $($p.ExitCode)"
    return [int]$p.ExitCode
  } catch {
    Log "$Name failed to start: $($_.Exception.Message)"
    return 9001
  }
}
function Invoke-PythonLogged([string]$PythonExe, [object[]]$ArgItems, [string]$Name) { return Invoke-NativeLogged $PythonExe $ArgItems $Name }
function Require-File([string]$p) { if (!(Test-Path $p)) { throw "Required file not found: $p" } }
function Is-WindowsAppsAlias([string]$p) { if ([string]::IsNullOrWhiteSpace($p)) { return $true }; return ($p -like "*\Microsoft\WindowsApps\*") }
function Decode-Payload($src, $dst) {
  if (-not ("AvsPayloadCodec" -as [type])) {
    Add-Type -TypeDefinition @"
using System;
using System.IO;
using System.Text;
public static class AvsPayloadCodec {
  public static void Decode(string src, string dst) {
    byte[] key = Encoding.UTF8.GetBytes("AVS-1.22C-local-bat-install-key-20260526");
    byte[] b = File.ReadAllBytes(src);
    for (int i = 0; i < b.Length; i++) {
      b[i] = (byte)(b[i] ^ key[i % key.Length] ^ ((i * 31 + 17) & 255));
    }
    File.WriteAllBytes(dst, b);
  }
}
"@
  }
  [AvsPayloadCodec]::Decode($src, $dst)
}
function Test-ZipPayload([string]$ZipPath) {
  if (!(Test-Path -LiteralPath $ZipPath)) { throw "Decoded payload zip was not created: $ZipPath" }
  $info = Get-Item -LiteralPath $ZipPath
  if ($info.Length -lt 4) { throw "Decoded payload zip is empty or too small: $ZipPath" }
  $fs = [System.IO.File]::OpenRead($ZipPath)
  try {
    $sig = New-Object byte[] 4
    [void]$fs.Read($sig, 0, 4)
    if ($sig[0] -ne 0x50 -or $sig[1] -ne 0x4B) { throw "Decoded payload is not a ZIP file. The package payload may be corrupted." }
  } finally {
    $fs.Dispose()
  }
  Add-Type -AssemblyName System.IO.Compression.FileSystem
  $zip = $null
  try {
    $zip = [System.IO.Compression.ZipFile]::OpenRead($ZipPath)
    if ($zip.Entries.Count -le 0) { throw "Decoded payload ZIP has no entries." }
  } finally {
    if ($zip) { $zip.Dispose() }
  }
}
function Test-PythonExe([string]$p) {
  if ([string]::IsNullOrWhiteSpace($p)) { return $false }
  if (Is-WindowsAppsAlias $p) { return $false }
  if (!(Test-Path -LiteralPath $p)) { return $false }
  $outFile = Join-Path (Get-SafeNativeWorkDir) ("avs_py_probe_" + [Guid]::NewGuid().ToString("N") + ".out")
  $errFile = Join-Path (Get-SafeNativeWorkDir) ("avs_py_probe_" + [Guid]::NewGuid().ToString("N") + ".err")
  try {
    $exit = Invoke-NativeLogged $p @('-c','import sys; raise SystemExit(0 if sys.version_info >= (3,10) else 1)') 'python_probe'
    return ($exit -eq 0)
  } catch {
    return $false
  } finally {
    Remove-Item -LiteralPath $outFile,$errFile -Force -ErrorAction SilentlyContinue
  }
}
function Add-Candidate([System.Collections.Generic.List[string]]$list, [string]$p) { if (![string]::IsNullOrWhiteSpace($p)) { try { $pp=$p.Trim().Trim('"'); if ($list -notcontains $pp) { [void]$list.Add($pp) } } catch {} } }
function Get-LocalPythonCandidates([string]$AppDir) { $list = New-Object System.Collections.Generic.List[string]; $pp=Join-Path $AppDir 'python_path.txt'; if (Test-Path $pp) { try { Add-Candidate $list (Get-Content $pp -ErrorAction SilentlyContinue | Select-Object -First 1) } catch {} }; Add-Candidate $list (Join-Path $AppDir 'runtime\python\Scripts\python.exe'); Add-Candidate $list (Join-Path $AppDir 'runtime\python\python.exe'); Add-Candidate $list (Join-Path $AppDir '.venv\Scripts\python.exe'); return $list }
function Resolve-LocalPython([string]$AppDir) { foreach ($c in (Get-LocalPythonCandidates $AppDir)) { if (Test-PythonExe $c) { return $c } }; return $null }
function Get-SeedPythonCandidates() {
  $list = New-Object System.Collections.Generic.List[string]
  Add-Candidate $list $env:AVS_SEED_PYTHON
  foreach ($rootKey in @('HKCU:\Software\Python\PythonCore','HKLM:\Software\Python\PythonCore','HKLM:\Software\WOW6432Node\Python\PythonCore')) {
    try {
      if (!(Test-Path -LiteralPath $rootKey)) { continue }
      Get-ChildItem -LiteralPath $rootKey -ErrorAction SilentlyContinue | ForEach-Object {
        $installPathKey = Join-Path $_.PSPath 'InstallPath'
        try {
          $props = Get-ItemProperty -LiteralPath $installPathKey -ErrorAction SilentlyContinue
          if ($props.ExecutablePath) { Add-Candidate $list ([string]$props.ExecutablePath) }
          if ($props.'(default)') {
            $installRoot = [string]$props.'(default)'
            Add-Candidate $list (Join-Path $installRoot 'python.exe')
            Add-Candidate $list (Join-Path $installRoot 'Scripts\python.exe')
          }
          $defaultPath = (Get-Item -LiteralPath $installPathKey -ErrorAction SilentlyContinue).GetValue('')
          if ($defaultPath) {
            $installRoot = [string]$defaultPath
            Add-Candidate $list (Join-Path $installRoot 'python.exe')
            Add-Candidate $list (Join-Path $installRoot 'Scripts\python.exe')
          }
        } catch {}
      }
    } catch {}
  }
  foreach ($cmd in @('py -3.14','py -3.13','py -3.12','py -3.11','py -3.10','python','python3')) {
    try { $parts=$cmd.Split(' '); $exe=$parts[0]; $args=@(); if ($parts.Length -gt 1) { $args += $parts[1..($parts.Length-1)] }; $args += @('-c','import sys; print(sys.executable)'); $out=& $exe @args 2>$null | Select-Object -First 1; if ($LASTEXITCODE -eq 0 -and $out) { Add-Candidate $list $out } } catch {}
  }
  foreach ($base in @($env:LocalAppData, $env:ProgramFiles, ${env:ProgramFiles(x86)})) {
    if ([string]::IsNullOrWhiteSpace($base)) { continue }
    foreach ($rel in @('Programs\Python','Python','Python313','Python312','Python311','Python310','Python314')) {
      $d=Join-Path $base $rel
      if (Test-Path $d) { try { Get-ChildItem -Path $d -Filter python.exe -Recurse -ErrorAction SilentlyContinue | ForEach-Object { Add-Candidate $list $_.FullName } } catch {} }
    }
    foreach ($wild in @('Python\pythoncore-*','Programs\Python\Python*','Python\Python*')) {
      $parent = Split-Path -Parent (Join-Path $base $wild)
      $leaf = Split-Path -Leaf $wild
      if (Test-Path -LiteralPath $parent) {
        try {
          Get-ChildItem -Path $parent -Directory -Filter $leaf -ErrorAction SilentlyContinue | ForEach-Object {
            Add-Candidate $list (Join-Path $_.FullName 'python.exe')
            Add-Candidate $list (Join-Path $_.FullName 'Scripts\python.exe')
          }
        } catch {}
      }
    }
  }
  return $list
}
function Get-InstalledPythonRoots() {
  $roots = New-Object System.Collections.Generic.List[string]
  function Add-Root([string]$p) {
    if ([string]::IsNullOrWhiteSpace($p)) { return }
    try {
      $root = $p.Trim().Trim('"')
      if ((Split-Path -Leaf $root) -ieq 'python.exe') { $root = Split-Path -Parent $root }
      if ((Split-Path -Leaf $root) -ieq 'Scripts') { $root = Split-Path -Parent $root }
      $py = Join-Path $root 'python.exe'
      if ((Test-Path -LiteralPath $py) -and ($roots -notcontains $root)) { [void]$roots.Add($root) }
    } catch {}
  }
  foreach ($rootKey in @('HKCU:\Software\Python\PythonCore','HKLM:\Software\Python\PythonCore','HKLM:\Software\WOW6432Node\Python\PythonCore')) {
    try {
      if (!(Test-Path -LiteralPath $rootKey)) { continue }
      Get-ChildItem -LiteralPath $rootKey -ErrorAction SilentlyContinue | ForEach-Object {
        $installPathKey = Join-Path $_.PSPath 'InstallPath'
        try {
          $props = Get-ItemProperty -LiteralPath $installPathKey -ErrorAction SilentlyContinue
          if ($props.ExecutablePath) { Add-Root ([string]$props.ExecutablePath) }
          $defaultPath = (Get-Item -LiteralPath $installPathKey -ErrorAction SilentlyContinue).GetValue('')
          if ($defaultPath) { Add-Root ([string]$defaultPath) }
        } catch {}
      }
    } catch {}
  }
  foreach ($base in @($env:LocalAppData, $env:ProgramFiles, ${env:ProgramFiles(x86)})) {
    if ([string]::IsNullOrWhiteSpace($base)) { continue }
    foreach ($rel in @('Python\pythoncore-3.14-64','Python\pythoncore-3.13-64','Python\pythoncore-3.12-64','Programs\Python\Python314','Programs\Python\Python313','Programs\Python\Python312','Programs\Python\Python311','Python314','Python313','Python312','Python311')) {
      Add-Root (Join-Path $base $rel)
    }
  }
  return $roots
}
function Copy-InstalledPythonRuntime([string]$TargetDir) {
  foreach ($root in (Get-InstalledPythonRoots)) {
    $srcPy = Join-Path $root 'python.exe'
    if (!(Test-PythonExe $srcPy)) { continue }
    Log "Trying local AVS Python runtime copy from installed Python: $root"
    try {
      if (Test-Path -LiteralPath $TargetDir) { Remove-Item -LiteralPath $TargetDir -Recurse -Force -ErrorAction SilentlyContinue }
      New-Item -ItemType Directory -Force -Path $TargetDir | Out-Null
      Get-ChildItem -LiteralPath $root -Force | ForEach-Object {
        Copy-Item -LiteralPath $_.FullName -Destination (Join-Path $TargetDir $_.Name) -Recurse -Force -ErrorAction Stop
      }
      $localPy = Join-Path $TargetDir 'python.exe'
      if (Test-PythonExe $localPy) { Log "Local AVS Python runtime copied: $localPy"; return $localPy }
      Log "Copied Python runtime did not pass probe: $root"
    } catch {
      Log "Copy installed Python runtime failed: $($_.Exception.Message)"
    }
  }
  return $null
}
function Create-LocalVenvFromSeed([string]$TargetDir) {
  foreach ($seed in (Get-SeedPythonCandidates)) {
    if (!(Test-PythonExe $seed)) { continue }
    Log "Trying clean local AVS venv creation from seed Python: $seed"
    try {
      if (Test-Path $TargetDir) { Remove-Item $TargetDir -Recurse -Force -ErrorAction SilentlyContinue }
      New-Item -ItemType Directory -Force -Path (Split-Path -Parent $TargetDir) | Out-Null
      $exit = Invoke-NativeLogged $seed @('-m','venv',$TargetDir) 'create_local_venv'
      $venvPy=Join-Path $TargetDir 'Scripts\python.exe'
      if ($exit -eq 0 -and (Test-PythonExe $venvPy)) { Log "Local AVS venv created: $venvPy"; return $venvPy }
    } catch { Log "Seed Python venv creation failed: $($_.Exception.Message)" }
  }
  return $null
}
function Install-BundledPython([string]$Installer, [string]$TargetDir) { New-Item -ItemType Directory -Force -Path $TargetDir | Out-Null; $args=@('/quiet','InstallAllUsers=0','PrependPath=0','AppendPath=0','Include_launcher=0','InstallLauncherAllUsers=0','Include_test=0','Include_pip=1','Include_tcltk=0','Shortcuts=0','AssociateFiles=0','CompileAll=0',("TargetDir=$TargetDir"),("DefaultJustForMeTargetDir=$TargetDir"),("DefaultCustomTargetDir=$TargetDir"),'/log',$PyInstallLog); try { $p=Start-Process -FilePath $Installer -ArgumentList (Join-Args $args) -WindowStyle Hidden -Wait -PassThru -WorkingDirectory (Get-SafeNativeWorkDir); Log "Bundled Python installer exit code: $($p.ExitCode)" } catch { Log "Bundled Python installer failed to start: $($_.Exception.Message)" }; $direct=Join-Path $TargetDir 'python.exe'; if (Test-PythonExe $direct) { return $direct }; return $null }
function Ensure-AvsPythonAppPath([string]$PyExe) {
  try {
    $pyDir = Split-Path -Parent $PyExe
    $pth = Get-ChildItem -LiteralPath $pyDir -Filter 'python*._pth' -ErrorAction SilentlyContinue | Select-Object -First 1
    if (!$pth) { return }
    $lines = @(Get-Content -LiteralPath $pth.FullName -ErrorAction Stop)
    if ($lines -contains '..\..') { return }
    $out = New-Object System.Collections.Generic.List[string]
    $inserted = $false
    foreach ($line in $lines) {
      if (-not $inserted -and $line.Trim().ToLowerInvariant() -eq 'import site') {
        $out.Add('..\..')
        $inserted = $true
      }
      $out.Add($line)
    }
    if (-not $inserted) { $out.Add('..\..') }
    Set-Content -LiteralPath $pth.FullName -Value $out -Encoding ASCII -Force
    Log "Python app path enabled in $($pth.Name)"
  } catch {
    Log "Python app path update failed: $($_.Exception.Message)"
  }
}
function Checkpoint-MarketDataBeforePreserve([string]$srcRoot) {
  $db = Join-Path $srcRoot 'data\market_data.db'
  $wal = $db + '-wal'
  if (!(Test-Path -LiteralPath $db)) { return $true }
  if (!(Test-Path -LiteralPath $wal) -or (Get-Item -LiteralPath $wal).Length -lt 4096) { return $true }
  $py = Join-Path $srcRoot 'runtime\python\python.exe'
  if (!(Test-Path -LiteralPath $py)) {
    Log "Market DB WAL exists but source Python is unavailable. Market DB migration will be skipped to prevent partial data copy."
    return $false
  }
  $code = "import sqlite3,sys; db=sys.argv[1]; c=sqlite3.connect(db,timeout=120); c.execute('PRAGMA busy_timeout=120000'); r=c.execute('PRAGMA wal_checkpoint(TRUNCATE)').fetchone(); print('AVS_MARKET_DB_CHECKPOINT',r); c.close(); raise SystemExit(0 if (not r or int(r[0] or 0)==0) else 2)"
  $exit = Invoke-PythonLogged $py @('-c',$code,$db) 'market_data_checkpoint_before_migration'
  $walBytes = if (Test-Path -LiteralPath $wal) { (Get-Item -LiteralPath $wal).Length } else { 0 }
  if ($exit -ne 0 -or $walBytes -gt 1048576) {
    Log "Market DB checkpoint incomplete. exit=$exit wal_bytes=$walBytes. Market DB migration will be skipped and data sync will rebuild it."
    return $false
  }
  Log "Market DB checkpoint complete before migration. wal_bytes=$walBytes"
  return $true
}
function Checkpoint-LedgerBeforePreserve([string]$srcRoot) {
  $db = Join-Path $srcRoot 'data\avs_ledger.db'
  if (!(Test-Path -LiteralPath $db)) { return $true }
  $py = Join-Path $srcRoot 'runtime\python\python.exe'
  if (!(Test-Path -LiteralPath $py)) {
    Log "Ledger DB exists but source Python is unavailable. Ledger migration will rebuild it safely."
    return $false
  }
  $code = @'
import sqlite3,sys
db=sys.argv[1]
conn=None
try:
    conn=sqlite3.connect(db,timeout=120)
    conn.execute("PRAGMA busy_timeout=120000")
    result=str((conn.execute("PRAGMA integrity_check").fetchone() or [""])[0])
    if result.lower() != "ok":
        print("AVS_LEDGER_INTEGRITY_FAILED", result)
        raise SystemExit(2)
    checkpoint=conn.execute("PRAGMA wal_checkpoint(TRUNCATE)").fetchone()
    print("AVS_LEDGER_CHECKPOINT", checkpoint)
    raise SystemExit(0 if (not checkpoint or int(checkpoint[0] or 0)==0) else 3)
finally:
    if conn is not None:
        conn.close()
'@
  $exit = Invoke-PythonLogged $py @('-c',$code,$db) 'ledger_checkpoint_before_migration'
  $walBytes = if (Test-Path -LiteralPath ($db + '-wal')) { (Get-Item -LiteralPath ($db + '-wal')).Length } else { 0 }
  if ($exit -ne 0 -or $walBytes -gt 1048576) {
    Log "Ledger DB is not safe to preserve. exit=$exit wal_bytes=$walBytes. It will be archived and rebuilt from CSV/account data."
    return $false
  }
  Log "Ledger DB integrity/checkpoint complete before migration. wal_bytes=$walBytes"
  return $true
}
function Copy-Preserve([string]$srcRoot, [string]$dstRoot) {
  if (!(Test-Path $srcRoot)) { return }
  New-Item -ItemType Directory -Force -Path $dstRoot | Out-Null
  $copyMarketDb = Checkpoint-MarketDataBeforePreserve $srcRoot
  $copyLedgerDb = Checkpoint-LedgerBeforePreserve $srcRoot
  foreach ($name in 'app_settings.json','.env','avs_license.lic','license_status.json','database','decision_cache','backups') {
    $srcKeep=Join-Path $srcRoot $name
    if (Test-Path $srcKeep) { Copy-Item $srcKeep (Join-Path $dstRoot $name) -Recurse -Force -ErrorAction SilentlyContinue }
  }
  $srcPortfolio = Join-Path $srcRoot 'portfolio'
  if (Test-Path $srcPortfolio) {
    $dstPortfolio = Join-Path $dstRoot 'portfolio'
    New-Item -ItemType Directory -Force -Path $dstPortfolio | Out-Null
    Get-ChildItem -LiteralPath $srcPortfolio -Force | Where-Object { $_.Name -notin @('portfolio_orders.csv','order_plan_review.csv','dynamic_recheck_queue.csv') } | ForEach-Object { Copy-Item $_.FullName (Join-Path $dstPortfolio $_.Name) -Recurse -Force -ErrorAction SilentlyContinue }
  }
  $archiveStamp = Get-Date -Format 'yyyyMMdd_HHmmss'
  $archiveRoot = Join-Path $dstRoot ("backups\migrated_runtime_" + $archiveStamp)
  foreach ($name in 'logs','jobs','self_check_reports','scenario_test_reports','ui_e2e_reports','full_qa_reports') {
    $srcArchive = Join-Path $srcRoot $name
    if (Test-Path $srcArchive) { New-Item -ItemType Directory -Force -Path $archiveRoot | Out-Null; Copy-Item $srcArchive (Join-Path $archiveRoot $name) -Recurse -Force -ErrorAction SilentlyContinue }
  }
  foreach ($name in 'portfolio_orders.csv','order_plan_review.csv','dynamic_recheck_queue.csv') {
    $srcOrder = Join-Path $srcPortfolio $name
    if (Test-Path $srcOrder) { $orderArchive = Join-Path $archiveRoot 'order_plans'; New-Item -ItemType Directory -Force -Path $orderArchive | Out-Null; Copy-Item $srcOrder (Join-Path $orderArchive $name) -Force -ErrorAction SilentlyContinue }
  }
  $srcData = Join-Path $srcRoot 'data'
  if (Test-Path $srcData) {
    $dstData = Join-Path $dstRoot 'data'
    New-Item -ItemType Directory -Force -Path $dstData | Out-Null
    Get-ChildItem -LiteralPath $srcData -Force | Where-Object {
      $_.Name -notin @('market_data.db-wal','market_data.db-shm','avs_ledger.db-wal','avs_ledger.db-shm') -and ($copyMarketDb -or $_.Name -ne 'market_data.db') -and ($copyLedgerDb -or $_.Name -ne 'avs_ledger.db')
    } | ForEach-Object { Copy-Item $_.FullName (Join-Path $dstData $_.Name) -Recurse -Force -ErrorAction SilentlyContinue }
    if (!$copyMarketDb) {
      Set-Content -LiteralPath (Join-Path $dstData 'MARKET_DATA_RESYNC_REQUIRED.txt') -Value 'Previous market DB WAL could not be checkpointed safely. Run Data Sync after installation.' -Encoding ASCII -Force
    }
    if (!$copyLedgerDb) {
      $ledgerArchive = Join-Path $archiveRoot 'ledger_repair_source'
      New-Item -ItemType Directory -Force -Path $ledgerArchive | Out-Null
      Get-ChildItem -LiteralPath $srcData -Force | Where-Object { $_.Name -like 'avs_ledger.db*' } | ForEach-Object { Copy-Item $_.FullName (Join-Path $ledgerArchive $_.Name) -Force -ErrorAction SilentlyContinue }
      Set-Content -LiteralPath (Join-Path $dstData 'LEDGER_REBUILD_REQUIRED.txt') -Value 'Previous ledger DB failed integrity validation. It was archived during install and will be rebuilt from CSV/account data.' -Encoding ASCII -Force
    }
  }
  $rt=Join-Path $srcRoot 'runtime'
  if (Test-Path $rt) {
    $rtDst=Join-Path $dstRoot 'runtime'
    New-Item -ItemType Directory -Force -Path $rtDst | Out-Null
    Get-ChildItem $rt -Force | Where-Object { $_.Name -notin @('kis_access_token_cache.json','kis_token_issue.lock','last_kis_token_error.json','api_connection_status.json','html_server.pid','scheduler_worker.pid','auto_trade_worker.pid','service_state.json','ai_execution_status.json','runtime_config_snapshot.json','machine_id.json','auto_trade_heartbeat.json','schedule_heartbeat.json','trading_orchestrator_last.json','trading_orchestrator_error.json','startup_data_prepare.json','market_data_db_migration.json','data_sync_fast_cache.json','data_sync_daily_state.json','scan_result_cache.json','scan_postprocess_result.json','candidate_strategy_audit.csv','candidate_strategy_audit.json','candidate_strategy_audit_cache.json','candidate_factor_score_audit.json','candidate_bucket_separation_audit.json','price_sync_retry.json','operation_timeline.json','python') } | ForEach-Object { Copy-Item $_.FullName (Join-Path $rtDst $_.Name) -Recurse -Force -ErrorAction SilentlyContinue }
  }
}
function New-AVSShortcut([object]$Shell, [string]$Path, [string]$Target, [string]$WorkingDirectory, [string]$Icon, [string]$Arguments = "") {
  try {
    $lnk = $Shell.CreateShortcut($Path)
    $lnk.TargetPath = $Target
    $lnk.WorkingDirectory = $WorkingDirectory
    if (![string]::IsNullOrWhiteSpace($Arguments)) { $lnk.Arguments = $Arguments }
    if (![string]::IsNullOrWhiteSpace($Icon) -and (Test-Path -LiteralPath $Icon)) { $lnk.IconLocation = $Icon }
    $lnk.Save()
    Log "Shortcut created: $Path -> $Target"
  } catch {
    Log "Shortcut create failed: $Path / $($_.Exception.Message)"
  }
}
function Create-AVSShortcuts([string]$InstallRoot, [string]$AppDir) {
  try {
    $shell = New-Object -ComObject WScript.Shell
    $desktop = [Environment]::GetFolderPath('Desktop')
    if ([string]::IsNullOrWhiteSpace($desktop)) {
      try {
        $desktopReg = (Get-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\User Shell Folders" -Name Desktop -ErrorAction SilentlyContinue).Desktop
        if (-not [string]::IsNullOrWhiteSpace($desktopReg)) { $desktop = [Environment]::ExpandEnvironmentVariables($desktopReg) }
      } catch {}
    }
    if ([string]::IsNullOrWhiteSpace($desktop) -or !(Test-Path -LiteralPath $desktop)) {
      foreach ($candidate in @((Join-Path $env:USERPROFILE "Desktop"), (Join-Path $env:USERPROFILE "OneDrive\Desktop"))) {
        if (-not [string]::IsNullOrWhiteSpace($candidate) -and (Test-Path -LiteralPath $candidate)) { $desktop = $candidate; break }
      }
    }
    if ([string]::IsNullOrWhiteSpace($desktop)) { throw "Desktop folder could not be resolved." }
    $programs = [Environment]::GetFolderPath('Programs')
    if ([string]::IsNullOrWhiteSpace($programs)) {
      $programs = Join-Path $env:APPDATA "Microsoft\Windows\Start Menu\Programs"
    }
    $startDir = Join-Path $programs "AVS"
    New-Item -ItemType Directory -Force -Path $startDir | Out-Null
    $icon = Join-Path $AppDir "assets\avs_desktop.ico"
    $run = Join-Path $AppDir "AVS_Run_Silent.vbs"
    $setupExe = Join-Path $InstallRoot "AVS_Setup.exe"
    $uninstallArgs = '--uninstall --install-root "' + $InstallRoot + '"'
    $runName = "AVS " + (-join ([char[]](0xC2E4,0xD589))) + ".lnk"
    $uninstallName = "AVS " + (-join ([char[]](0xC0AD,0xC81C))) + ".lnk"
    foreach ($name in @($runName, $uninstallName, "AVS.lnk", "AVS Boot Check.lnk", "AVS " + (-join ([char[]](0xAC80,0xC99D))) + ".lnk", "AVS " + (-join ([char[]](0xC885,0xB8CC))) + ".lnk")) {
      Remove-Item -LiteralPath (Join-Path $desktop $name) -Force -ErrorAction SilentlyContinue
      Remove-Item -LiteralPath (Join-Path $startDir $name) -Force -ErrorAction SilentlyContinue
    }
    New-AVSShortcut $shell (Join-Path $desktop $runName) $run $AppDir $icon
    New-AVSShortcut $shell (Join-Path $startDir $runName) $run $AppDir $icon
    New-AVSShortcut $shell (Join-Path $startDir $uninstallName) $setupExe $InstallRoot $icon $uninstallArgs
  } catch {
    Log "Shortcut setup failed: $($_.Exception.Message)"
  }
}
function Register-AVSUninstall([string]$InstallRoot, [string]$AppDir) {
  try {
    $key = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\Alpha Viper System"
    $setupExe = Join-Path $InstallRoot "AVS_Setup.exe"
    $icon = Join-Path $AppDir "assets\avs_desktop.ico"
    $uninstallString = '"' + $setupExe + '" --uninstall --install-root "' + $InstallRoot + '"'
    New-Item -Path $key -Force | Out-Null
    New-ItemProperty -Path $key -Name "DisplayName" -Value "Alpha Viper System" -PropertyType String -Force | Out-Null
    New-ItemProperty -Path $key -Name "DisplayVersion" -Value $Version -PropertyType String -Force | Out-Null
    New-ItemProperty -Path $key -Name "Publisher" -Value "Alpha Viper System" -PropertyType String -Force | Out-Null
    New-ItemProperty -Path $key -Name "InstallLocation" -Value $InstallRoot -PropertyType String -Force | Out-Null
    New-ItemProperty -Path $key -Name "UninstallString" -Value $uninstallString -PropertyType String -Force | Out-Null
    New-ItemProperty -Path $key -Name "DisplayIcon" -Value $icon -PropertyType String -Force | Out-Null
    New-ItemProperty -Path $key -Name "NoModify" -Value 1 -PropertyType DWord -Force | Out-Null
    New-ItemProperty -Path $key -Name "NoRepair" -Value 1 -PropertyType DWord -Force | Out-Null
    Log "Windows Apps uninstall entry registered."
  } catch {
    Log "Windows Apps uninstall entry registration failed: $($_.Exception.Message)"
  }
}
function Restore-Preserve([string]$srcRoot, [string]$dstRoot) { if (!(Test-Path $srcRoot)) { return }; Copy-Item (Join-Path $srcRoot '*') $dstRoot -Recurse -Force -ErrorAction SilentlyContinue }
function Find-PreviousAvsAppDir([string]$CurrentInstallRoot) {
  $cands = @()
  $roots = New-Object System.Collections.Generic.List[string]
  if ($env:AVS_PREVIOUS_INSTALL_ROOT) { [void]$roots.Add([Environment]::ExpandEnvironmentVariables($env:AVS_PREVIOUS_INSTALL_ROOT)) }
  foreach ($keyPath in @('HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall','HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall','HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall')) {
    try {
      Get-ChildItem -LiteralPath $keyPath -ErrorAction SilentlyContinue | ForEach-Object {
        $props = Get-ItemProperty -LiteralPath $_.PSPath -ErrorAction SilentlyContinue
        if ($props.DisplayName -like '*Alpha Viper*' -and $props.InstallLocation) { [void]$roots.Add([string]$props.InstallLocation) }
      }
    } catch {}
  }
  # The uninstall registry contains only one AVS entry and can point to an
  # older install. Include sibling version folders so the most recently used
  # settings are not replaced by stale credentials during an upgrade.
  try {
    $currentResolved = [IO.Path]::GetFullPath($CurrentInstallRoot).TrimEnd('\')
    $installParent = Split-Path -Parent $currentResolved
    if (Test-Path -LiteralPath $installParent) {
      Get-ChildItem -LiteralPath $installParent -Directory -ErrorAction SilentlyContinue |
        Where-Object { $_.Name -match '^AVS_[0-9]+(?:\.[0-9]+)+(?:$|_)' } |
        ForEach-Object { [void]$roots.Add($_.FullName) }
    }
  } catch {}
  foreach ($root in ($roots | Select-Object -Unique)) {
    try {
      $resolved = (Resolve-Path -LiteralPath $root -ErrorAction Stop).Path.TrimEnd('\')
      if ($resolved -eq $CurrentInstallRoot.TrimEnd('\')) { continue }
      $app = if ((Split-Path -Leaf $resolved) -ieq 'AVS_APP') { $resolved } else { Join-Path $resolved 'AVS_APP' }
      if (!(Test-Path -LiteralPath $app)) { continue }
      $settingsPath = Join-Path $app 'app_settings.json'
      $hasSettings = Test-Path -LiteralPath $settingsPath
      $settingsTime = if ($hasSettings) { (Get-Item -LiteralPath $settingsPath).LastWriteTimeUtc } else { [datetime]::MinValue }
      $score = 0
      if ($hasSettings) { $score += 10 }
      if (Test-Path (Join-Path $app 'avs_license.lic')) { $score += 20 }
      if (Test-Path (Join-Path $app 'data\avs_ledger.db')) { $score += 30 }
      if (Test-Path (Join-Path $app 'data\market_data.db')) { $score += 30 }
      $version = [version]'0.0'
      try {
        $rawVersion = Read-InstalledAvsVersion $app
        if (-not [string]::IsNullOrWhiteSpace($rawVersion)) { $version = [version]$rawVersion }
      } catch {}
      $cands += [pscustomobject]@{
        Path=$app
        HasSettings=$hasSettings
        SettingsTime=$settingsTime
        Version=$version
        Score=$score
        Time=(Get-Item -LiteralPath $app).LastWriteTimeUtc
      }
    } catch {}
  }
  $best = $cands | Sort-Object -Property `
    @{Expression='HasSettings';Descending=$true}, `
    @{Expression='SettingsTime';Descending=$true}, `
    @{Expression='Version';Descending=$true}, `
    @{Expression='Score';Descending=$true}, `
    @{Expression='Time';Descending=$true} | Select-Object -First 1
  if ($best) { return [string]$best.Path }
  return $null
}

function Remove-TransientTokenFiles([string]$root) { foreach ($rel in @('runtime\kis_access_token_cache.json','runtime\kis_token_issue.lock','runtime\last_kis_token_error.json','runtime\api_connection_status.json','runtime\html_server.pid','runtime\scheduler_worker.pid','auto_trade_worker.pid','runtime\auto_trade_worker.pid','runtime\machine_id.json','runtime\service_state.json','runtime\ai_execution_status.json','runtime\runtime_config_snapshot.json','kis_access_token_cache.json','api_connection_status.json')) { Remove-Item (Join-Path $root $rel) -Force -ErrorAction SilentlyContinue } }
function Remove-PackagedScanOutputs([string]$root) {
  foreach ($rel in @(
    'short_candidates.csv',
    'pre_breakout_candidates.csv',
    'mid_candidates.csv',
    'buy_candidates.csv',
    'long_candidates.csv',
    'decision_cache\expert_candidates.csv',
    'decision_cache\expert_final_buylist.csv',
    'runtime\data_sync_fast_cache.json',
    'runtime\scan_result_cache.json',
    'runtime\scan_postprocess_result.json',
    'runtime\candidate_strategy_audit.csv',
    'runtime\candidate_strategy_audit.json',
    'runtime\candidate_strategy_audit_cache.json',
    'runtime\candidate_factor_score_audit.json',
    'runtime\candidate_bucket_separation_audit.json',
    'runtime\price_sync_retry.json',
    'runtime\operation_timeline.json'
  )) {
    Remove-Item (Join-Path $root $rel) -Force -ErrorAction SilentlyContinue
  }
}
function Install-Dependencies([string]$PyExe, [string]$AppDir) {
  $PyRoot = Split-Path -Parent $PyExe
  $PyScripts = Join-Path $PyRoot "Scripts"
  if (Test-Path $PyRoot) { $env:PATH = "$PyRoot;$env:PATH" }
  if (Test-Path $PyScripts) { $env:PATH = "$PyScripts;$env:PATH" }
  $Req=Join-Path $AppDir "requirements.txt"
  $MinReq=Join-Path $AppDir "requirements_runtime_minimal.txt"
  $Constraint=Join-Path $AppDir "requirements_constraints.txt"
  Log "Installing/checking runtime-minimal Python dependencies in isolated AVS runtime."
  $preCheckExit = Invoke-PythonLogged $PyExe @('-c','import fastapi, uvicorn, pandas, pydantic, requests; print("AVS_CORE_DEPENDENCIES_ALREADY_OK")') 'dependency_precheck'
  if ($preCheckExit -eq 0) {
    Remove-Item (Join-Path $AppDir "DEPENDENCY_INSTALL_FAILED.txt") -Force -ErrorAction SilentlyContinue
    Log "Core dependencies already available in local AVS runtime. Skipping pip install."
    return
  }
  [void](Invoke-PythonLogged $PyExe @('-m','ensurepip','--upgrade') 'ensurepip')
  $pipExit = 0
  if (Test-Path $MinReq) {
    $pipArgs = @('-m','pip','install','--disable-pip-version-check','--no-warn-script-location','--prefer-binary','--no-cache-dir','-r',$MinReq)
    if (Test-Path $Constraint) { $pipArgs += @('-c',$Constraint) }
    $pipExit = Invoke-PythonLogged $PyExe $pipArgs 'pip_install_runtime_minimal'
  } elseif (Test-Path $Req) {
    $pipArgs = @('-m','pip','install','--disable-pip-version-check','--no-warn-script-location','--prefer-binary','--no-cache-dir','-r',$Req)
    if (Test-Path $Constraint) { $pipArgs += @('-c',$Constraint) }
    $pipExit = Invoke-PythonLogged $PyExe $pipArgs 'pip_install_requirements'
  }
  if ($pipExit -ne 0) { Set-Content -Path (Join-Path $AppDir "DEPENDENCY_INSTALL_FAILED.txt") -Value "Dependency install failed. See logs/install.log" -Encoding ASCII; throw "Dependency install failed. See logs/install.log" }
  if ($env:AVS_INSTALL_FULL_DEPS -eq "1" -and (Test-Path $Req)) {
    Log "Optional full dependency install requested by AVS_INSTALL_FULL_DEPS=1."
    $pipArgs = @('-m','pip','install','--disable-pip-version-check','--no-warn-script-location','--prefer-binary','--no-cache-dir','-r',$Req)
    if (Test-Path $Constraint) { $pipArgs += @('-c',$Constraint) }
    [void](Invoke-PythonLogged $PyExe $pipArgs 'pip_install_optional_full_requirements')
  }
  $checkExit = Invoke-PythonLogged $PyExe @('-c','import fastapi, uvicorn, pandas, pydantic, requests; print("AVS_CORE_DEPENDENCIES_OK")') 'dependency_import_check'
  if ($checkExit -ne 0) { throw "Core dependency import check failed. See logs/install.log" }
  Remove-Item (Join-Path $AppDir "DEPENDENCY_INSTALL_FAILED.txt") -Force -ErrorAction SilentlyContinue
}
function Test-CoreDependencyReady([string]$PyExe) {
  if ([string]::IsNullOrWhiteSpace($PyExe) -or !(Test-Path -LiteralPath $PyExe)) { return $false }
  $exit = Invoke-PythonLogged $PyExe @('-c','import fastapi, uvicorn, pandas, pydantic, requests; print("AVS_CORE_DEPENDENCIES_READY")') 'dependency_runtime_probe'
  return ($exit -eq 0)
}
Require-File (Join-Path $PayloadDir "app_payload.enc")
Log "$ProductName $Version local folder install"; Log "AVS_SAFE_MIGRATION: target-folder data is preserved; previous-version migration checkpoints market DB and excludes WAL/SHM."; Log "Installer package verified"; Log "Install root: $InstallRoot"; Log "App path: $AppDir"
$ExistingVersion = ""
if (Test-Path -LiteralPath $AppDir) {
  $ExistingVersion = Read-InstalledAvsVersion $AppDir
  if (-not [string]::IsNullOrWhiteSpace($ExistingVersion)) {
    $cmp = Compare-AvsVersion $ExistingVersion $Version
    if ($cmp -gt 0) {
      Log "Installed AVS version is newer than this package. Installed=$ExistingVersion, Package=$Version"
      throw "Downgrade blocked. Use a package version equal to or newer than $ExistingVersion."
    } elseif ($cmp -lt 0) {
      Log "Patch/update mode: AVS $ExistingVersion -> $Version. Target-folder user data will be preserved."
    } else {
      Log "Repair/reinstall mode: AVS $Version over same version. Target-folder user data will be preserved."
    }
  } else {
    Log "Existing AVS_APP found without readable version. Treating as repair/update target and preserving target-folder user data."
  }
}
$StaleHelper = Join-Path $ScriptDir "Kill_Stale_AVS_Server.ps1"
if ($env:AVS_INSTALL_SKIP_RUNTIME_STOP -eq "1") {
  Log "AVS_INSTALL_SKIP_RUNTIME_STOP=1: runtime stop helper skipped for install test."
} elseif (Test-Path -LiteralPath $StaleHelper) {
  Log "Stopping existing AVS runtime before install/update."
  try {
    $staleArgs = @('-NoProfile','-ExecutionPolicy','Bypass','-File',$StaleHelper,'-AppDir',$AppDir,'-ExpectedVersion',$Version,'-ExpectedBuildId',$PackageManifest.build_id,'-Force','-AlsoKillLegacyUi','-Quiet')
    & powershell.exe @staleArgs
    $staleExit = $LASTEXITCODE
    Log "Stale runtime stop helper exit code: $staleExit"
    Start-Sleep -Milliseconds 900
  } catch { Log "Stale runtime stop helper failed: $($_.Exception.Message)" }
}
$CrossVersionHelper = Join-Path $ScriptDir "Stop_Old_AVS_Runtimes.ps1"
if ($env:AVS_INSTALL_SKIP_RUNTIME_STOP -eq "1") {
  Log "AVS_INSTALL_SKIP_RUNTIME_STOP=1: cross-version runtime cleanup skipped for install test."
} elseif (Test-Path -LiteralPath $CrossVersionHelper) {
  Log "Stopping obsolete AVS server, scheduler, and auto-trade worker processes from previous installs."
  & powershell.exe -NoProfile -NonInteractive -ExecutionPolicy Bypass -File $CrossVersionHelper -CurrentAppDir $AppDir -Quiet
  if ($LASTEXITCODE -ne 0) {
    throw "Previous AVS runtime cleanup failed with exit code $LASTEXITCODE."
  }
} else {
  throw "Cross-version AVS runtime cleanup helper is missing: $CrossVersionHelper"
}
$PreserveDir=Join-Path $SetupDir ("preserve_" + (Get-Date -Format 'yyyyMMdd_HHmmss'))
if (Test-Path $AppDir) {
  Log "Existing AVS_APP found. Preserving user data."
  Copy-Preserve $AppDir $PreserveDir
} else {
  if ($env:AVS_INSTALL_SKIP_PREVIOUS_MIGRATION -eq "1") {
    Log "AVS_INSTALL_SKIP_PREVIOUS_MIGRATION=1: clean install test; previous-version data migration skipped."
  } else {
    $PreviousAppDir = Find-PreviousAvsAppDir $InstallRoot
    if ($PreviousAppDir) {
      Log "No AVS_APP at target path. Safely migrating user data from previous install: $PreviousAppDir"
      $ExistingVersion = Read-InstalledAvsVersion $PreviousAppDir
      Copy-Preserve $PreviousAppDir $PreserveDir
    } else {
      Log "No existing AVS_APP at target path and no previous AVS install found. Clean install mode."
    }
  }
}
$PayloadZip=Join-Path $SetupDir "app_payload.zip"; Decode-Payload (Join-Path $PayloadDir "app_payload.enc") $PayloadZip; Test-ZipPayload $PayloadZip; Add-Type -AssemblyName System.IO.Compression.FileSystem
Remove-Item $AppDir -Recurse -Force -ErrorAction SilentlyContinue; New-Item -ItemType Directory -Force -Path $AppDir | Out-Null; [System.IO.Compression.ZipFile]::ExtractToDirectory($PayloadZip,$AppDir); if (Test-Path $PreserveDir) { Restore-Preserve $PreserveDir $AppDir; Log "User data restored." }; Remove-PackagedScanOutputs $AppDir; Remove-Item $PayloadZip -Force -ErrorAction SilentlyContinue
foreach ($d in 'data','runtime','database','decision_cache','portfolio','logs','jobs','backups') { New-Item -ItemType Directory -Force -Path (Join-Path $AppDir $d) | Out-Null }; Remove-TransientTokenFiles $AppDir
$PyDir=Join-Path $AppDir "runtime\python"
$PyExe=Resolve-LocalPython $AppDir
if ($PyExe -and !(Test-CoreDependencyReady $PyExe)) {
  Log "Resolved local Python runtime is incomplete or has broken dependencies. Rebuilding AVS local runtime."
  Remove-Item -LiteralPath $PyDir -Recurse -Force -ErrorAction SilentlyContinue
  Remove-Item -LiteralPath (Join-Path $AppDir "python_path.txt") -Force -ErrorAction SilentlyContinue
  $PyExe = $null
}
if (!$PyExe) { $PyExe=Create-LocalVenvFromSeed $PyDir }
if (!$PyExe) {
  $PayloadPythonInstaller = Join-Path $PayloadDir "python-3.14.5-amd64.exe"
  if (Test-Path -LiteralPath $PayloadPythonInstaller) {
    Log "Local AVS venv creation failed. Trying bundled installer as fallback."
    $PyInstaller=Join-Path $SetupDir "python-3.14.5-amd64.exe"
    Copy-Item $PayloadPythonInstaller $PyInstaller -Force
    $PyExe=Install-BundledPython $PyInstaller $PyDir
  } else {
    Log "Local AVS runtime not found and bundled Python installer is not included in this package."
  }
}
if (!$PyExe) { Log "Bundled Python installer did not create a local runtime. Copying registered Python runtime into AVS runtime."; $PyExe=Copy-InstalledPythonRuntime $PyDir }
if (!$PyExe) { Log "Registered Python runtime copy failed. Retrying local AVS venv creation from registered Python."; $PyExe=Create-LocalVenvFromSeed $PyDir }
if (!$PyExe -or !(Test-PythonExe $PyExe)) { Log "Python runtime resolution failed. Local candidates checked:"; foreach ($c in (Get-LocalPythonCandidates $AppDir)) { Log " - $c" }; Log "Seed Python candidates checked:"; foreach ($c in (Get-SeedPythonCandidates)) { Log " - $c" }; throw "Python is not available as a local AVS runtime. Send logs/python_installer.log and logs/install.log." }
$appFull=(Resolve-Path $AppDir).Path.TrimEnd('\'); $pyFull=(Resolve-Path $PyExe).Path.TrimEnd('\'); if (!$pyFull.ToLower().StartsWith($appFull.ToLower())) { throw "Python runtime is not localized inside AVS_APP: $PyExe" }
Set-Content -Path (Join-Path $AppDir "python_path.txt") -Value $PyExe -Encoding ASCII -Force; Log "Python: $PyExe"
Ensure-AvsPythonAppPath $PyExe
Install-Dependencies $PyExe $AppDir
$Compile=Join-Path $SetupDir "compile_cleanup.py"
@'
from pathlib import Path
import py_compile, sys, shutil
root = Path(sys.argv[1]).resolve()
excluded_parts = {'runtime', '.venv', 'site-packages'}
files=[]
for p in root.rglob('*.py'):
    rel = p.relative_to(root)
    if any(part in excluded_parts for part in rel.parts):
        continue
    if rel.as_posix() == 'sitecustomize.py':
        continue
    files.append(p)
failed=[]
for p in files:
    try:
        py_compile.compile(str(p), cfile=str(p.with_suffix('.pyc')), doraise=True, optimize=1)
    except Exception as e:
        failed.append((str(p), repr(e)))
if failed:
    print('COMPILE_FAILED')
    for p,e in failed: print(p, e)
    sys.exit(2)
for p in files:
    try: p.unlink()
    except Exception as e: print('WARN_DELETE_FAILED', p, e)
for d in root.rglob('__pycache__'):
    try: shutil.rmtree(d)
    except Exception: pass
print('COMPILE_AND_SOURCE_CLEANUP_OK_RECURSIVE', len(files))
'@ | Set-Content -Path $Compile -Encoding ASCII
$compileExit = Invoke-PythonLogged $PyExe @($Compile,$AppDir) 'compile_cleanup'
if ($compileExit -ne 0) { Log "Compile/source cleanup failed with exit code $compileExit. Install stopped to prevent Python source exposure."; Set-Content -Path (Join-Path $AppDir "COMPILE_CLEANUP_FAILED.txt") -Value "Compile/source cleanup failed. Install stopped to prevent Python source exposure. See logs/install.log" -Encoding ASCII; throw "Compile/source cleanup failed. Install stopped to prevent Python source exposure." }
$LeakCheck=Join-Path $SetupDir "source_leak_check.py"
@'
from pathlib import Path
import sys
root = Path(sys.argv[1]).resolve()
excluded = {'runtime', '.venv', 'site-packages'}
leaks=[]
for p in root.rglob('*.py'):
    try: rel=p.relative_to(root)
    except Exception: continue
    if any(part in excluded for part in rel.parts):
        continue
    if rel.as_posix() == 'sitecustomize.py':
        continue
    leaks.append(str(rel))
if leaks:
    print('PY_SOURCE_LEAK_DETECTED')
    for x in leaks: print(x)
    sys.exit(3)
print('NO_PY_SOURCE_IN_APP_OK')
'@ | Set-Content -Path $LeakCheck -Encoding ASCII
$leakExit = Invoke-PythonLogged $PyExe @($LeakCheck,$AppDir) 'source_leak_check'
if ($leakExit -ne 0) { throw "Python source leak detected after install. Install stopped." }
@'
@echo off
cd /d "%~dp0"
call "%~dp0START_AVS.cmd"
'@ | Set-Content -Path (Join-Path $AppDir "RUN_AVS.cmd") -Encoding ASCII
foreach ($reportDir in @("self_check_reports","scenario_test_reports","ui_e2e_reports","full_qa_reports")) { New-Item -ItemType Directory -Force -Path (Join-Path $AppDir $reportDir) | Out-Null }
Set-Content -Path (Join-Path $InstallRoot "installed_path.txt") -Value $AppDir -Encoding ASCII -Force
Write-InstalledAvsVersionState $InstallRoot $AppDir $ExistingVersion $Version
# Copy launcher/support files to the selected install root so the user can run AVS from the install directory too.
foreach ($name in @('AVS.bat','AVS_Setup.exe','AVS_Setup.cmd','README_FIRST.txt','package_manifest.json')) {
  $src = Join-Path $PackageRoot $name
  if (Test-Path $src) { Copy-Item $src (Join-Path $InstallRoot $name) -Force -ErrorAction SilentlyContinue }
}
foreach ($dirName in @('scripts','tools','docs','payload')) {
  $srcDir = Join-Path $PackageRoot $dirName
  $dstDir = Join-Path $InstallRoot $dirName
  if (Test-Path $srcDir) { Copy-Item $srcDir $dstDir -Recurse -Force -ErrorAction SilentlyContinue }
}
if ($SkipShortcuts -or $env:AVS_INSTALL_SKIP_SHORTCUTS -eq '1') {
  Log 'Shortcut and Windows Apps uninstall registration skipped by installer option.'
} else {
  Create-AVSShortcuts $InstallRoot $AppDir
  Register-AVSUninstall $InstallRoot $AppDir
}
Log "Install complete. Installed path saved: $AppDir"
Write-Host ""
Write-Host "Install complete." -ForegroundColor Green
Write-Host "Installed path: $AppDir" -ForegroundColor Green
Write-Host "General users can run AVS_Setup.exe. Operators can run AVS.bat from this package or from: $InstallRoot" -ForegroundColor Green
try { $script:InstallMutex.ReleaseMutex(); $script:InstallMutex.Dispose() } catch {}
exit 0


















