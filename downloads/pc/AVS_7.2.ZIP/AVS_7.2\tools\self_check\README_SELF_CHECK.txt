AVS Self Check Tool v1.5.2C
Run AVS.bat -> 3. Self Check and Log Report.
Error codes: AVS-UI / AVS-API / AVS-NXT / AVS-SCH / AVS-AUTO / AVS-JOB / AVS-LIC.







