param(
  [string]$InstallRoot = "",
  [switch]$Uninstall,
  [string]$Mode = ""
)
$ErrorActionPreference = "Stop"
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$PackageRoot = Split-Path -Parent $ScriptDir
. (Join-Path $ScriptDir "AVS_Package_Common.ps1")
$PackageManifest = Get-AvsPackageManifest $PackageRoot
$Version = [string]$PackageManifest.version
$ProductName = [string]$PackageManifest.product_name
$DefaultInstallRoot = [string]$PackageManifest.default_install_root
$InstallScript = Join-Path $ScriptDir "Install_AVS.ps1"
$UninstallScript = Join-Path $ScriptDir "Uninstall_AVS.ps1"

function Quote-Arg([string]$Value) {
  if ($null -eq $Value) { return '""' }
  return '"' + ([string]$Value -replace '"','\"') + '"'
}

function Normalize-InstallPath([string]$Path) {
  if ([string]::IsNullOrWhiteSpace($Path)) { $Path = $DefaultInstallRoot }
  $Path = [Environment]::ExpandEnvironmentVariables($Path.Trim().Trim('"'))
  if ([string]::IsNullOrWhiteSpace($Path)) { return $DefaultInstallRoot }
  return $Path
}

function Show-UninstallWindow {
  param([string]$InitialInstallRoot)
  Add-Type -AssemblyName System.Windows.Forms
  Add-Type -AssemblyName System.Drawing
  [System.Windows.Forms.Application]::EnableVisualStyles()

  $form = New-Object System.Windows.Forms.Form
  $form.Text = "AVS Uninstall"
  $form.StartPosition = "CenterScreen"
  $form.Size = New-Object System.Drawing.Size -ArgumentList 760,520
  $form.MinimumSize = New-Object System.Drawing.Size -ArgumentList 720,480
  $form.FormBorderStyle = 'Sizable'

  $font = New-Object System.Drawing.Font -ArgumentList @("Malgun Gothic", [single]9, [System.Drawing.FontStyle]::Regular, [System.Drawing.GraphicsUnit]::Point)
  $titleFont = New-Object System.Drawing.Font -ArgumentList @("Malgun Gothic", [single]16, [System.Drawing.FontStyle]::Bold, [System.Drawing.GraphicsUnit]::Point)

  $title = New-Object System.Windows.Forms.Label
  $title.Text = "Alpha Viper System Uninstall"
  $title.Font = $titleFont
  $title.AutoSize = $true
  $title.Location = New-Object System.Drawing.Point -ArgumentList 24,22
  $form.Controls.Add($title)

  $desc = New-Object System.Windows.Forms.Label
  $desc.Text = "Choose how to remove AVS. The uninstall progress is shown below."
  $desc.Font = $font
  $desc.AutoSize = $true
  $desc.Location = New-Object System.Drawing.Point -ArgumentList 26,64
  $form.Controls.Add($desc)

  $lbl = New-Object System.Windows.Forms.Label
  $lbl.Text = "Install folder"
  $lbl.Font = $font
  $lbl.AutoSize = $true
  $lbl.Location = New-Object System.Drawing.Point -ArgumentList 26,106
  $form.Controls.Add($lbl)

  $txt = New-Object System.Windows.Forms.TextBox
  $txt.Font = $font
  $txt.Location = New-Object System.Drawing.Point -ArgumentList 116,102
  $txt.Size = New-Object System.Drawing.Size -ArgumentList 500,28
  $txt.Text = Normalize-InstallPath $InitialInstallRoot
  $form.Controls.Add($txt)

  $status = New-Object System.Windows.Forms.Label
  $status.Text = "Ready"
  $status.Font = New-Object System.Drawing.Font -ArgumentList @("Malgun Gothic", [single]10, [System.Drawing.FontStyle]::Bold, [System.Drawing.GraphicsUnit]::Point)
  $status.AutoSize = $true
  $status.Location = New-Object System.Drawing.Point -ArgumentList 26,146
  $form.Controls.Add($status)

  $progress = New-Object System.Windows.Forms.ProgressBar
  $progress.Location = New-Object System.Drawing.Point -ArgumentList 26,176
  $progress.Size = New-Object System.Drawing.Size -ArgumentList 690,24
  $progress.Style = 'Blocks'
  $form.Controls.Add($progress)

  $logBox = New-Object System.Windows.Forms.TextBox
  $logBox.Font = New-Object System.Drawing.Font -ArgumentList @("Consolas", [single]9, [System.Drawing.FontStyle]::Regular, [System.Drawing.GraphicsUnit]::Point)
  $logBox.Location = New-Object System.Drawing.Point -ArgumentList 26,220
  $logBox.Size = New-Object System.Drawing.Size -ArgumentList 690,200
  $logBox.Multiline = $true
  $logBox.ScrollBars = 'Vertical'
  $logBox.ReadOnly = $true
  $logBox.WordWrap = $true
  $logBox.BackColor = [System.Drawing.Color]::White
  $logBox.ForeColor = [System.Drawing.Color]::Black
  $form.Controls.Add($logBox)

  $keep = New-Object System.Windows.Forms.Button
  $keep.Text = "Keep user data"
  $keep.Font = $font
  $keep.Location = New-Object System.Drawing.Point -ArgumentList 360,438
  $keep.Size = New-Object System.Drawing.Size -ArgumentList 130,34
  $form.Controls.Add($keep)

  $full = New-Object System.Windows.Forms.Button
  $full.Text = "Full delete"
  $full.Font = $font
  $full.Location = New-Object System.Drawing.Point -ArgumentList 500,438
  $full.Size = New-Object System.Drawing.Size -ArgumentList 100,34
  $form.Controls.Add($full)

  $close = New-Object System.Windows.Forms.Button
  $close.Text = "Close"
  $close.Font = $font
  $close.Location = New-Object System.Drawing.Point -ArgumentList 610,438
  $close.Size = New-Object System.Drawing.Size -ArgumentList 100,34
  $close.Add_Click({ $form.Close() })
  $form.Controls.Add($close)

  function Append-UninstallLog([string]$Text) {
    if ([string]::IsNullOrEmpty($Text)) { return }
    $logBox.AppendText($Text)
    if (!$Text.EndsWith("`n")) { $logBox.AppendText("`r`n") }
    $logBox.SelectionStart = $logBox.TextLength
    $logBox.ScrollToCaret()
  }

  function Start-Uninstall([string]$SelectedMode) {
    try {
      $installPath = Normalize-InstallPath $txt.Text
      if (!(Test-Path -LiteralPath $UninstallScript)) { throw "Uninstall script not found: $UninstallScript" }
      $keep.Enabled = $false
      $full.Enabled = $false
      $status.Text = "Uninstalling"
      $progress.Style = 'Marquee'
      $logBox.Clear()
      Append-UninstallLog "Alpha Viper System $Version uninstall"
      Append-UninstallLog "Install root: $installPath"
      Append-UninstallLog "Mode: $SelectedMode"
      $argLine = "-NoProfile -ExecutionPolicy Bypass -File " + (Quote-Arg $UninstallScript) + " -InstallRoot " + (Quote-Arg $installPath) + " -Mode " + (Quote-Arg $SelectedMode) + " -Yes"
      $p = Start-Process -FilePath "powershell.exe" -ArgumentList $argLine -WindowStyle Hidden -PassThru -Wait -RedirectStandardOutput "$env:TEMP\avs_uninstall.out.log" -RedirectStandardError "$env:TEMP\avs_uninstall.err.log"
      if (Test-Path "$env:TEMP\avs_uninstall.out.log") { Append-UninstallLog (Get-Content "$env:TEMP\avs_uninstall.out.log" -Raw -ErrorAction SilentlyContinue) }
      if (Test-Path "$env:TEMP\avs_uninstall.err.log") { Append-UninstallLog (Get-Content "$env:TEMP\avs_uninstall.err.log" -Raw -ErrorAction SilentlyContinue) }
      $progress.Style = 'Blocks'
      if ($p.ExitCode -eq 0) {
        $progress.Value = 100
        $status.Text = "Uninstall complete"
        $close.Text = "Close"
      } else {
        $progress.Value = 0
        $status.Text = "Uninstall failed"
        $keep.Enabled = $true
        $full.Enabled = $true
      }
    } catch {
      [System.Windows.Forms.MessageBox]::Show($_.Exception.Message, "AVS Uninstall Error", 'OK', 'Error') | Out-Null
      $progress.Style = 'Blocks'
      $progress.Value = 0
      $status.Text = "Uninstall failed"
      $keep.Enabled = $true
      $full.Enabled = $true
    }
  }

  $keep.Add_Click({ Start-Uninstall "KeepBackup" })
  $full.Add_Click({ Start-Uninstall "FullDelete" })
  [void]$form.ShowDialog()
}

if ($Uninstall) {
  Show-UninstallWindow -InitialInstallRoot $InstallRoot
  exit 0
}

try {
  Add-Type -AssemblyName System.Windows.Forms
  Add-Type -AssemblyName System.Drawing
  [System.Windows.Forms.Application]::EnableVisualStyles()

  $form = New-Object System.Windows.Forms.Form
  $form.Text = "AVS Setup"
  $form.StartPosition = "CenterScreen"
  $form.Size = New-Object System.Drawing.Size -ArgumentList 980,720
  $form.MinimumSize = New-Object System.Drawing.Size -ArgumentList 900,640
  $form.FormBorderStyle = 'Sizable'
  $form.MaximizeBox = $true

  $font = New-Object System.Drawing.Font -ArgumentList @("Malgun Gothic", [single]9, [System.Drawing.FontStyle]::Regular, [System.Drawing.GraphicsUnit]::Point)
  $titleFont = New-Object System.Drawing.Font -ArgumentList @("Malgun Gothic", [single]16, [System.Drawing.FontStyle]::Bold, [System.Drawing.GraphicsUnit]::Point)

  $title = New-Object System.Windows.Forms.Label
  $title.Text = "Alpha Viper System Setup"
  $title.Font = $titleFont
  $title.AutoSize = $true
  $title.Location = New-Object System.Drawing.Point -ArgumentList 24,22
  $form.Controls.Add($title)

  $desc = New-Object System.Windows.Forms.Label
  $desc.Text = "The install process is shown below. Run AVS from the desktop icon after setup completes."
  $desc.Font = $font
  $desc.AutoSize = $true
  $desc.Location = New-Object System.Drawing.Point -ArgumentList 26,64
  $form.Controls.Add($desc)

  $lbl = New-Object System.Windows.Forms.Label
  $lbl.Text = "Install folder"
  $lbl.Font = $font
  $lbl.AutoSize = $true
  $lbl.Location = New-Object System.Drawing.Point -ArgumentList 26,106
  $form.Controls.Add($lbl)

  $txt = New-Object System.Windows.Forms.TextBox
  $txt.Font = $font
  $txt.Location = New-Object System.Drawing.Point -ArgumentList 116,102
  $txt.Size = New-Object System.Drawing.Size -ArgumentList 630,28
  $txt.Text = $(if ([string]::IsNullOrWhiteSpace($InstallRoot)) { $DefaultInstallRoot } else { $InstallRoot })
  $form.Controls.Add($txt)

  $browse = New-Object System.Windows.Forms.Button
  $browse.Text = "Browse"
  $browse.Font = $font
  $browse.Location = New-Object System.Drawing.Point -ArgumentList 764,100
  $browse.Size = New-Object System.Drawing.Size -ArgumentList 120,32
  $browse.Add_Click({
    $dlg = New-Object System.Windows.Forms.FolderBrowserDialog
    $dlg.Description = "Select AVS install folder"
    $dlg.SelectedPath = $txt.Text
    if ($dlg.ShowDialog() -eq 'OK') { $txt.Text = $dlg.SelectedPath }
  })
  $form.Controls.Add($browse)

  $status = New-Object System.Windows.Forms.Label
  $status.Text = "Ready"
  $status.Font = New-Object System.Drawing.Font -ArgumentList @("Malgun Gothic", [single]10, [System.Drawing.FontStyle]::Bold, [System.Drawing.GraphicsUnit]::Point)
  $status.AutoSize = $true
  $status.Location = New-Object System.Drawing.Point -ArgumentList 26,154
  $form.Controls.Add($status)

  $progress = New-Object System.Windows.Forms.ProgressBar
  $progress.Location = New-Object System.Drawing.Point -ArgumentList 26,184
  $progress.Size = New-Object System.Drawing.Size -ArgumentList 910,24
  $progress.Style = 'Blocks'
  $progress.Minimum = 0
  $progress.Maximum = 100
  $progress.Value = 0
  $form.Controls.Add($progress)

  $logBox = New-Object System.Windows.Forms.TextBox
  $logBox.Font = New-Object System.Drawing.Font -ArgumentList @("Consolas", [single]9, [System.Drawing.FontStyle]::Regular, [System.Drawing.GraphicsUnit]::Point)
  $logBox.Location = New-Object System.Drawing.Point -ArgumentList 26,228
  $logBox.Size = New-Object System.Drawing.Size -ArgumentList 910,360
  $logBox.Multiline = $true
  $logBox.ScrollBars = 'Vertical'
  $logBox.ReadOnly = $true
  $logBox.WordWrap = $true
  $logBox.BackColor = [System.Drawing.Color]::White
  $logBox.ForeColor = [System.Drawing.Color]::Black
  $form.Controls.Add($logBox)

  $install = New-Object System.Windows.Forms.Button
  $install.Text = "Install"
  $install.Font = $font
  $install.Location = New-Object System.Drawing.Point -ArgumentList 690,610
  $install.Size = New-Object System.Drawing.Size -ArgumentList 120,36
  $form.Controls.Add($install)

  $cancel = New-Object System.Windows.Forms.Button
  $cancel.Text = "Close"
  $cancel.Font = $font
  $cancel.Location = New-Object System.Drawing.Point -ArgumentList 826,610
  $cancel.Size = New-Object System.Drawing.Size -ArgumentList 110,36
  $cancel.Add_Click({ $form.Close() })
  $form.Controls.Add($cancel)

  $script:proc = $null
  $script:outFile = $null
  $script:errFile = $null
  $script:lastOutLen = 0
  $script:lastErrLen = 0
  $script:installPath = $null
  $script:closingTicks = 0

  function Append-Log([string]$Text) {
    if ([string]::IsNullOrEmpty($Text)) { return }
    $Text = $Text -replace "`r`n|`n|`r", "`r`n"
    $logBox.AppendText($Text)
    if (!$Text.EndsWith("`r`n")) { $logBox.AppendText("`r`n") }
    $logBox.SelectionStart = $logBox.TextLength
    $logBox.ScrollToCaret()
  }

  function Read-NewText([string]$Path, [ref]$Offset) {
    if (!(Test-Path -LiteralPath $Path)) { return "" }
    try {
      $fs = [System.IO.File]::Open($Path, [System.IO.FileMode]::Open, [System.IO.FileAccess]::Read, [System.IO.FileShare]::ReadWrite)
      try {
        if ($fs.Length -le $Offset.Value) { return "" }
        $count = [int]($fs.Length - $Offset.Value)
        $buf = New-Object byte[] -ArgumentList $count
        $fs.Position = $Offset.Value
        [void]$fs.Read($buf, 0, $buf.Length)
        $Offset.Value = $fs.Position
        return [System.Text.Encoding]::UTF8.GetString($buf)
      } finally {
        $fs.Close()
      }
    } catch {
      return ""
    }
  }

  $timer = New-Object System.Windows.Forms.Timer
  $timer.Interval = 500
  $timer.Add_Tick({
    if ($script:outFile) { Append-Log (Read-NewText $script:outFile ([ref]$script:lastOutLen)) }
    if ($script:errFile) { Append-Log (Read-NewText $script:errFile ([ref]$script:lastErrLen)) }
    if ($script:proc -and -not $script:proc.HasExited) {
      if ($progress.Style -ne 'Marquee') { $progress.Style = 'Marquee' }
      return
    }
    if ($script:proc -and $script:proc.HasExited) {
      $timer.Stop()
      try { $script:proc.Refresh() } catch {}
      if ($script:outFile) { Append-Log (Read-NewText $script:outFile ([ref]$script:lastOutLen)) }
      if ($script:errFile) { Append-Log (Read-NewText $script:errFile ([ref]$script:lastErrLen)) }
      $exitCode = $script:proc.ExitCode
      $outText = ""
      $errText = ""
      try { if ($script:outFile -and (Test-Path -LiteralPath $script:outFile)) { $outText = Get-Content -Raw -Encoding UTF8 $script:outFile } } catch {}
      try { if ($script:errFile -and (Test-Path -LiteralPath $script:errFile)) { $errText = Get-Content -Raw -Encoding UTF8 $script:errFile } } catch {}
      $combinedLog = ($outText + "`n" + $errText)
      $successMarker = ($combinedLog -match "Install complete" -or $combinedLog -match "Installed path saved")
      if ($null -eq $exitCode -and $successMarker) { $exitCode = 0 }
      $progress.Style = 'Blocks'
      if ($exitCode -eq 0) {
        $progress.Value = 100
        $status.Text = "Install complete"
        Append-Log ""
        Append-Log "[OK] Install complete: $script:installPath"
        $install.Enabled = $false
        $cancel.Text = "Close"
        $script:proc = $null
        $script:closingTicks = 5
        $timer.Start()
        return
      }
      $progress.Value = 0
      $status.Text = "Install failed"
      Append-Log ""
      if ($null -eq $exitCode) {
        Append-Log "[ERROR] Install did not complete. Check the log above."
      } else {
        Append-Log "[ERROR] Install failed with exit code $exitCode"
      }
      $install.Enabled = $true
      $browse.Enabled = $true
      $cancel.Text = "Close"
      $script:proc = $null
      return
    }
    if ($script:closingTicks -gt 0) {
      $script:closingTicks -= 1
      if ($script:closingTicks -le 0) { $form.Close() }
    }
  })

  $install.Add_Click({
    try {
      $script:installPath = Normalize-InstallPath $txt.Text
      if (!(Test-Path -LiteralPath $InstallScript)) { throw "Install script not found: $InstallScript" }
      $txt.Text = $script:installPath
      $install.Enabled = $false
      $browse.Enabled = $false
      $status.Text = "Installing"
      $progress.Style = 'Marquee'
      $logBox.Clear()
      Append-Log "Alpha Viper System $Version setup"
      Append-Log "Installer package verified"
      Append-Log "Install root: $script:installPath"
      Append-Log ""
      $tempRoot = Join-Path ([System.IO.Path]::GetTempPath()) ("AVS_SETUP_" + [guid]::NewGuid().ToString("N"))
      New-Item -ItemType Directory -Force -Path $tempRoot | Out-Null
      $script:outFile = Join-Path $tempRoot "install.out.log"
      $script:errFile = Join-Path $tempRoot "install.err.log"
      $script:lastOutLen = 0
      $script:lastErrLen = 0
      $argLine = "-NoProfile -ExecutionPolicy Bypass -File " + (Quote-Arg $InstallScript) + " -InstallRoot " + (Quote-Arg $script:installPath)
      $script:proc = Start-Process -FilePath "powershell.exe" -ArgumentList $argLine -WindowStyle Hidden -PassThru -RedirectStandardOutput $script:outFile -RedirectStandardError $script:errFile
      $timer.Start()
    } catch {
      [System.Windows.Forms.MessageBox]::Show($_.Exception.Message, "AVS Setup Error", 'OK', 'Error') | Out-Null
      $install.Enabled = $true
      $browse.Enabled = $true
      $status.Text = "Install failed"
      $progress.Style = 'Blocks'
      $progress.Value = 0
    }
  })

  [void]$form.ShowDialog()
} catch {
  $setupErr = $_.Exception.ToString()
  $setupErrPath = Join-Path $env:TEMP "AVS_User_Setup.error.log"
  Set-Content -LiteralPath $setupErrPath -Value $setupErr -Encoding UTF8
  try {
    Add-Type -AssemblyName System.Windows.Forms
    [System.Windows.Forms.MessageBox]::Show("AVS setup window failed to start.`r`n`r`n$setupErr`r`n`r`nLog: $setupErrPath", "AVS Setup Error", 'OK', 'Error') | Out-Null
  } catch {
    Write-Host "AVS Setup failed: $setupErr"
    Write-Host "Log: $setupErrPath"
  }
  exit 1
}








