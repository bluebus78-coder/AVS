param([string]$PackageRoot = "")
$ErrorActionPreference = "Stop"

$ScriptDir = if ([string]::IsNullOrWhiteSpace($PSScriptRoot)) { Split-Path -Parent $MyInvocation.MyCommand.Path } else { $PSScriptRoot }
. (Join-Path $ScriptDir "AVS_Package_Common.ps1")
if ([string]::IsNullOrWhiteSpace($PackageRoot)) { $PackageRoot = Split-Path -Parent $ScriptDir }
$PackageRoot = (Resolve-Path -LiteralPath $PackageRoot).Path
$Manifest = Get-AvsPackageManifest $PackageRoot
$Version = [string]$Manifest.version

function Decode-PayloadFast([string]$Src,[string]$Dst) {
  if (-not ("AvsPayloadValidatorCodec" -as [type])) {
    Add-Type -TypeDefinition @"
using System;
using System.IO;
using System.Text;
public static class AvsPayloadValidatorCodec {
  public static void Decode(string src, string dst) {
    byte[] key = Encoding.UTF8.GetBytes("AVS-1.22C-local-bat-install-key-20260526");
    byte[] b = File.ReadAllBytes(src);
    for (int i = 0; i < b.Length; i++) {
      b[i] = (byte)(b[i] ^ key[i % key.Length] ^ ((i * 31 + 17) & 255));
    }
    File.WriteAllBytes(dst, b);
  }
}
"@
  }
  [AvsPayloadValidatorCodec]::Decode($Src, $Dst)
}

function Fail([string]$Message) {
  Write-Host "[FAIL] $Message" -ForegroundColor Red
  exit 1
}

$payload = Join-Path $PackageRoot "payload\app_payload.enc"
if (!(Test-Path -LiteralPath $payload)) { Fail "payload\app_payload.enc not found." }

$badVersionPatterns = @('1\.7\.21')
$scripts = Get-ChildItem -LiteralPath (Join-Path $PackageRoot "scripts") -Filter *.ps1 -File
foreach ($script in $scripts) {
  $text = Get-Content -LiteralPath $script.FullName -Raw -Encoding UTF8
  foreach ($pat in $badVersionPatterns) {
    if ($text -match $pat) { Fail "stale version text found in $($script.Name): $pat" }
  }
}

$tempDir = Join-Path ([System.IO.Path]::GetTempPath()) ("AVS_PACKAGE_VALIDATE_" + [guid]::NewGuid().ToString("N"))
New-Item -ItemType Directory -Force -Path $tempDir | Out-Null
try {
  $zipPath = Join-Path $tempDir "app_payload.zip"
  Decode-PayloadFast $payload $zipPath
  Add-Type -AssemblyName System.IO.Compression.FileSystem
  $zip = [System.IO.Compression.ZipFile]::OpenRead($zipPath)
  try {
    if ($zip.Entries.Count -le 0) { Fail "decoded payload zip has no entries." }
    $versionEntry = $zip.GetEntry("VERSION.txt")
    if ($null -eq $versionEntry) { Fail "payload VERSION.txt not found." }
    $reader = New-Object System.IO.StreamReader($versionEntry.Open(), [System.Text.Encoding]::UTF8)
    try { $payloadVersion = ($reader.ReadToEnd()).Trim() } finally { $reader.Dispose() }
    if ($payloadVersion -ne $Version) { Fail "payload version mismatch. manifest=$Version payload=$payloadVersion" }
  } finally {
    if ($zip) { $zip.Dispose() }
  }
} finally {
  Remove-Item -LiteralPath $tempDir -Recurse -Force -ErrorAction SilentlyContinue
}

Write-Host "[PASS] AVS package validated. version=$Version root=$PackageRoot"
exit 0
