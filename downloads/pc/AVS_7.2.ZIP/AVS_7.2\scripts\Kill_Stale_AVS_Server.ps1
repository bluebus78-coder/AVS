param(
  [string]$AppDir = "",
  [string]$ExpectedVersion = "1.7.29",
  [string]$ExpectedBuildId = "1.7.29",
  [string]$BaseUrl = "http://127.0.0.1:8518",
  [switch]$Force,
  [switch]$Quiet,
  [switch]$AlsoKillLegacyUi
)
$ErrorActionPreference = "Continue"
$ScriptDir = if ([string]::IsNullOrWhiteSpace($PSScriptRoot)) { Split-Path -Parent $MyInvocation.MyCommand.Path } else { $PSScriptRoot }
try {
  . (Join-Path $ScriptDir "AVS_Package_Common.ps1")
  $PackageManifest = Get-AvsPackageManifest (Split-Path -Parent $ScriptDir)
} catch {
  $PackageManifest = $null
}

function Repair-ArgText([string]$v) {
  if ([string]::IsNullOrWhiteSpace($v)) { return "" }
  $s = [string]$v
  $s = $s -replace '[\x00-\x1F]', ''
  foreach ($marker in @(' -ExpectedVersion ', ' -ExpectedBuildId ', ' -BaseUrl ', ' -Force', ' -Quiet', ' -AlsoKillLegacyUi')) {
    $idx = $s.IndexOf($marker, [System.StringComparison]::OrdinalIgnoreCase)
    if ($idx -ge 0) { $s = $s.Substring(0, $idx); break }
  }
  $s = $s -replace '\s+1\.\d+\.\d+C(\s+-.+)?$', ''
  $s = $s.Trim().Trim('"')
  try { $s = [System.IO.Path]::GetFullPath($s) } catch {}
  if ($s.Length -gt 3 -and $s.EndsWith('\')) { $s = $s.TrimEnd('\') }
  return $s
}
$AppDir = Repair-ArgText $AppDir
$ExpectedVersion = ([string]$ExpectedVersion).Trim().Trim('"')
if ([string]::IsNullOrWhiteSpace($ExpectedVersion)) { $ExpectedVersion = "1.7.29" }
$ExpectedBuildId = ([string]$ExpectedBuildId).Trim().Trim('"')
if ([string]::IsNullOrWhiteSpace($ExpectedBuildId)) { $ExpectedBuildId = "1.7.29" }
if ($PackageManifest) {
  if ($ExpectedVersion -eq "1.7.29" -or [string]::IsNullOrWhiteSpace($ExpectedVersion)) { $ExpectedVersion = [string]$PackageManifest.version }
  if ($ExpectedBuildId -eq "1.7.29" -or [string]::IsNullOrWhiteSpace($ExpectedBuildId)) { $ExpectedBuildId = [string]$PackageManifest.build_id }
}
function Out([string]$m) { if (-not $Quiet) { Write-Host $m } }
function Ensure-LogDir {
  try {
    if ($AppDir -and (Test-Path -LiteralPath $AppDir)) {
      $d = Join-Path $AppDir "logs"
      New-Item -ItemType Directory -Force -LiteralPath $d | Out-Null
      return $d
    }
  } catch {}
  return $null
}
$LogDir = Ensure-LogDir
$LogPath = if ($LogDir) { Join-Path $LogDir "stale_server_guard.log" } else { $null }
function Log([string]$m) {
  Out $m
  if ($LogPath) { try { Add-Content -LiteralPath $LogPath -Encoding UTF8 -Value ("$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') $m") } catch {} }
}
function Normalize-PathText([string]$p) {
  if ([string]::IsNullOrWhiteSpace($p)) { return "" }
  try { $full = [System.IO.Path]::GetFullPath($p) } catch { $full = [string]$p }
  return $full.TrimEnd([char[]]"\/").ToLowerInvariant()
}
function Short-Sha256([string]$s) {
  if ([string]::IsNullOrWhiteSpace($s)) { return "" }
  try {
    $sha = [System.Security.Cryptography.SHA256]::Create()
    $bytes = [System.Text.Encoding]::UTF8.GetBytes($s)
    return (([System.BitConverter]::ToString($sha.ComputeHash($bytes))) -replace '-', '').ToLowerInvariant().Substring(0, 16)
  } catch { return "" }
}
function Expected-AppHash {
  $n = Normalize-PathText $AppDir
  if ($n) { return Short-Sha256 $n }
  return ""
}
function Get-ApiInfo {
  try {
    $uri = "$BaseUrl/api/v1/health?stale_check=" + [DateTimeOffset]::Now.ToUnixTimeMilliseconds()
    $r = Invoke-RestMethod -Uri $uri -Method GET -TimeoutSec 2 -Headers @{"Cache-Control"="no-cache"}
    $d = $r.data
    $build = ""
    try {
      if ($d.build_id) { $build = [string]$d.build_id }
      elseif ($d.package_revision) { $build = [string]$d.package_revision }
    } catch { $build = "" }
    return [pscustomobject]@{
      Version = [string]$d.version
      BuildId = $build
      AppDir = [string]$d.app_dir
      AppDirHash = [string]$d.app_dir_hash
      Pid = [string]$d.pid
    }
  } catch { return $null }
}
function Get-PortPids([int]$Port) {
  $ids = @()
  try {
    $conns = Get-NetTCPConnection -LocalPort $Port -State Listen -ErrorAction SilentlyContinue
    foreach ($c in $conns) { if ($c.OwningProcess -and ($ids -notcontains [int]$c.OwningProcess)) { $ids += [int]$c.OwningProcess } }
  } catch {}
  if ($ids.Count -eq 0) {
    try {
      $lines = netstat -ano -p tcp 2>$null | Select-String (":" + $Port + "\s")
      foreach ($ln in $lines) {
        $parts = (($ln.Line -replace '^\s+','') -split '\s+')
        if ($parts.Count -ge 5 -and $parts[3] -eq 'LISTENING') {
          $parsedPid = 0
          if ([int]::TryParse($parts[4], [ref]$parsedPid) -and $parsedPid -gt 0 -and ($ids -notcontains $parsedPid)) { $ids += $parsedPid }
        }
      }
    } catch {}
  }
  return $ids
}
function Kill-Pids([int[]]$Pids, [string]$Why) {
  $killed = 0
  foreach ($procId in $Pids) {
    try {
      $p = Get-Process -Id $procId -ErrorAction SilentlyContinue
      if ($p) {
        Log "[AVS] Stopping AVS runtime PID $procId ($($p.ProcessName)) reason=$Why"
        Stop-Process -Id $procId -Force -ErrorAction Stop
        $killed += 1
      }
    } catch { Log "[AVS][WARN] Failed to stop PID $procId : $($_.Exception.Message)" }
  }
  return $killed
}
function Get-ProtectedProcessIds {
  $protected = @()
  $cur = [int]$PID
  while ($cur -gt 0 -and ($protected -notcontains $cur)) {
    $protected += $cur
    try {
      $proc = Get-CimInstance Win32_Process -Filter "ProcessId=$cur" -ErrorAction SilentlyContinue
      if ($null -eq $proc -or $null -eq $proc.ParentProcessId) { break }
      $cur = [int]$proc.ParentProcessId
    } catch {
      break
    }
  }
  return $protected
}
function Kill-AppDirProcesses([string]$Dir, [string]$Why) {
  if ([string]::IsNullOrWhiteSpace($Dir)) { return 0 }
  $needle = $Dir.TrimEnd('\')
  $ids = @()
  $protectedIds = @(Get-ProtectedProcessIds)
  $runtimeHosts = @('python.exe','pythonw.exe','wscript.exe','cscript.exe')
  try {
    Get-CimInstance Win32_Process -ErrorAction SilentlyContinue |
      Where-Object {
        $pidNum = [int]$_.ProcessId
        if ($pidNum -le 0 -or ($protectedIds -contains $pidNum)) { return $false }
        $exe = [string]$_.ExecutablePath
        $cmd = [string]$_.CommandLine
        $name = ([string]$_.Name).ToLowerInvariant()
        $exeInsideApp = ($exe -and $exe.StartsWith($needle, [System.StringComparison]::OrdinalIgnoreCase))
        $cmdUsesApp = ($cmd -and $cmd.IndexOf($needle, [System.StringComparison]::OrdinalIgnoreCase) -ge 0)
        $isRuntimeHost = ($runtimeHosts -contains $name)
        return ($exeInsideApp -or ($isRuntimeHost -and $cmdUsesApp))
      } |
      ForEach-Object {
        $pidNum = [int]$_.ProcessId
        if ($pidNum -gt 0 -and ($ids -notcontains $pidNum)) { $ids += $pidNum }
      }
  } catch {}
  if ($ids.Count -gt 0) { return (Kill-Pids $ids $Why) }
  return 0
}
function Kill-AllAvsBackgroundWorkers([string]$Why) {
  $ids = @()
  $protectedIds = @(Get-ProtectedProcessIds)
  try {
    Get-CimInstance Win32_Process -ErrorAction SilentlyContinue |
      Where-Object {
        $pidNum = [int]$_.ProcessId
        if ($pidNum -le 0 -or ($protectedIds -contains $pidNum)) { return $false }
        $name = ([string]$_.Name).ToLowerInvariant()
        if ($name -notin @('python.exe','pythonw.exe')) { return $false }
        $cmd = [string]$_.CommandLine
        if ([string]::IsNullOrWhiteSpace($cmd)) { return $false }
        $isAvsApp = ($cmd -match '\\AVS_1\.[^\\]+\\AVS_APP\\')
        $isWorker = ($cmd -match '(scheduler_worker|auto_trade_worker)\.pyc?' -or $cmd -match '(scheduler_worker|auto_trade_worker)\.py')
        return ($isAvsApp -and $isWorker)
      } |
      ForEach-Object {
        $pidNum = [int]$_.ProcessId
        if ($pidNum -gt 0 -and ($ids -notcontains $pidNum)) { $ids += $pidNum }
      }
  } catch {}
  if ($ids.Count -gt 0) { return (Kill-Pids $ids $Why) }
  return 0
}

$api = Get-ApiInfo
$pids8518 = @(Get-PortPids 8518)
$expectedHash = Expected-AppHash
$reason = ""
if ($null -eq $api -and $pids8518.Count -eq 0) {
  Log "[AVS] No existing AVS server detected on port 8518."
} elseif ($Force) {
  $reason = "force_stop"
} elseif ($null -eq $api -and $pids8518.Count -gt 0) {
  $reason = "port_occupied_no_health"
} elseif ($api.Version -ne $ExpectedVersion) {
  $reason = "api_version_mismatch running=$($api.Version) expected=$ExpectedVersion"
} elseif ($ExpectedBuildId -and $api.BuildId -ne $ExpectedBuildId) {
  $reason = "api_build_id_mismatch running=$($api.BuildId) expected=$ExpectedBuildId"
} elseif ($expectedHash -and $api.AppDirHash -and ($api.AppDirHash -ne $expectedHash)) {
  $reason = "api_app_dir_hash_mismatch running=$($api.AppDirHash) expected=$expectedHash"
} elseif ($expectedHash -and (-not $api.AppDirHash)) {
  if ($api.AppDir) {
    $runningDir = Normalize-PathText $api.AppDir
    $expectedDir = Normalize-PathText $AppDir
    if ($runningDir -ne $expectedDir) { $reason = "api_app_dir_mismatch running=$runningDir expected=$expectedDir" }
  } else { $reason = "api_app_dir_unverified" }
} else {
  Log "[AVS] Existing AVS API matches current package. version=$ExpectedVersion build=$ExpectedBuildId app_hash=$expectedHash"
}
if ($reason) {
  Log "[AVS][WARN] Existing AVS runtime is stale or unsafe: $reason"
  if ($pids8518.Count -gt 0) { [void](Kill-Pids $pids8518 $reason) }
  Start-Sleep -Milliseconds 800
}
if ($Force -or $AlsoKillLegacyUi) {
  $pids8501 = @(Get-PortPids 8501)
  if ($pids8501.Count -gt 0) { [void](Kill-Pids $pids8501 "legacy_ui_port_8501_cleanup") }
}

if ($Force -and $AppDir) {
  [void](Kill-AppDirProcesses $AppDir "target_appdir_process_cleanup")
  [void](Kill-AllAvsBackgroundWorkers "all_avs_background_worker_cleanup")
  foreach ($relPid in @('runtime\scheduler_worker.pid','runtime\auto_trade_worker.pid')) {
    try {
      $pidFile = Join-Path $AppDir $relPid
      if (Test-Path -LiteralPath $pidFile) {
        $pidText = Get-Content -LiteralPath $pidFile -Encoding UTF8 -ErrorAction SilentlyContinue | Select-Object -First 1
        $pidFromFile = 0
        if ([int]::TryParse(([string]$pidText).Trim(), [ref]$pidFromFile) -and $pidFromFile -gt 0) {
          [void](Kill-Pids @($pidFromFile) "runtime_pid_file_cleanup_$relPid")
        }
        Remove-Item -LiteralPath $pidFile -Force -ErrorAction SilentlyContinue
      }
    } catch { Log "[AVS][WARN] PID file cleanup failed $relPid : $($_.Exception.Message)" }
  }
}
$after = Get-ApiInfo
if ($reason -and $after -and (($after.Version -ne $ExpectedVersion) -or ($ExpectedBuildId -and $after.BuildId -ne $ExpectedBuildId))) {
  Log "[AVS][ERROR] stale API still responds after cleanup. running=$($after.Version)/$($after.BuildId) expected=$ExpectedVersion/$ExpectedBuildId"
  exit 2
}
exit 0















