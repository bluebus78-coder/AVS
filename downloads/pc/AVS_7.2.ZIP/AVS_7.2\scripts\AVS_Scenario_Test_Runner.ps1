param(
  [string]$AppDir = "",
  [string]$BaseUrl = "http://127.0.0.1:8518",
  [switch]$OpenReport
)
$ErrorActionPreference = "Stop"
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
. (Join-Path $ScriptDir "AVS_Package_Common.ps1")
$PackageRoot = Split-Path -Parent $ScriptDir
$PackageManifest = Get-AvsPackageManifest $PackageRoot
$Version = [string]$PackageManifest.version
function Read-FirstLine([string]$Path) {
  try { if (Test-Path -LiteralPath $Path) { return (Get-Content -LiteralPath $Path -Encoding UTF8 -ErrorAction Stop | Select-Object -First 1) } } catch {}
  return ""
}
function Normalize-PathText([string]$PathText) {
  if ([string]::IsNullOrWhiteSpace($PathText)) { return "" }
  $v = [Environment]::ExpandEnvironmentVariables(([string]$PathText).Trim().Trim('"'))
  try { $v = [System.IO.Path]::GetFullPath($v) } catch {}
  try { if (Test-Path -LiteralPath $v) { $v = (Resolve-Path -LiteralPath $v).Path } } catch {}
  return $v
}
function Test-AvsAppDir([string]$PathText) {
  $v = Normalize-PathText $PathText
  if ([string]::IsNullOrWhiteSpace($v)) { return $false }
  return ((Test-Path -LiteralPath (Join-Path $v "START_AVS.cmd")) -and ((Test-Path -LiteralPath (Join-Path $v "VERSION.txt")) -or (Test-Path -LiteralPath (Join-Path $v "VERSION.json"))))
}
function Resolve-AvsAppDir([string]$InputDir) {
  $scriptPath = $PSCommandPath
  if ([string]::IsNullOrWhiteSpace($scriptPath)) { $scriptPath = $MyInvocation.MyCommand.Path }
  if ([string]::IsNullOrWhiteSpace($scriptPath)) { $scriptPath = $MyInvocation.ScriptName }
  if ([string]::IsNullOrWhiteSpace($scriptPath)) { $scriptDir = if ([string]::IsNullOrWhiteSpace($PSScriptRoot)) { (Get-Location).Path } else { $PSScriptRoot } }
  else { $scriptDir = Split-Path -Parent $scriptPath }
  $packageRoot = Split-Path -Parent $scriptDir
  $candidates = New-Object System.Collections.Generic.List[string]
  foreach ($c in @($InputDir, (Join-Path $InputDir "AVS_APP"), $packageRoot, (Join-Path $packageRoot "AVS_APP"), (Join-Path $PackageManifest.default_install_root "AVS_APP"))) {
    if (-not [string]::IsNullOrWhiteSpace($c)) { [void]$candidates.Add($c) }
  }
  foreach ($root in @($InputDir, $packageRoot, $PackageManifest.default_install_root)) {
    if ([string]::IsNullOrWhiteSpace($root)) { continue }
    $line = Read-FirstLine (Join-Path $root "installed_path.txt")
    if (-not [string]::IsNullOrWhiteSpace($line)) { [void]$candidates.Add($line) }
  }
  foreach ($c in $candidates) { $v = Normalize-PathText $c; if (Test-AvsAppDir $v) { return $v } }
  return (Normalize-PathText $InputDir)
}
function Add-Result([string]$Id,[string]$Category,[string]$Level,[string]$Name,[string]$Expected,[string]$Actual,[string]$Action) {
  $script:Results += [pscustomobject]@{ id=$Id; category=$Category; level=$Level; name=$Name; expected=$Expected; actual=$Actual; action=$Action }
}
function Escape-Html([string]$Text) {
  if ($null -eq $Text) { return "" }
  return [System.Net.WebUtility]::HtmlEncode($Text)
}
if ([string]::IsNullOrWhiteSpace($AppDir)) { $AppDir = (Get-Location).Path }
$OriginalAppDir = $AppDir
$AppDir = Resolve-AvsAppDir $AppDir
if (-not (Test-AvsAppDir $AppDir)) {
  Write-Host "[AVS][ERROR] AVS_APP could not be resolved. Input=$OriginalAppDir, Resolved=$AppDir" -ForegroundColor Red
  exit 6
}
$script:Results = @()
$AppVersion = Read-FirstLine (Join-Path $AppDir "VERSION.txt")
if ($AppVersion -eq $Version) { Add-Result "SCN-001" "VERSION" "PASS" "Version" $Version $AppVersion "" } else { Add-Result "SCN-001" "VERSION" "FAIL" "Version" $Version $AppVersion "Install current package." }
$serverPath = Join-Path $AppDir "api\server.py"
$serverPycPath = Join-Path $AppDir "api\server.pyc"
$frontPath = Join-Path $AppDir "assets\avs_frontend.bundle.js"
$serverText = ""
$frontText = ""
try { if (Test-Path -LiteralPath $serverPath) { $serverText = Get-Content -LiteralPath $serverPath -Raw -Encoding UTF8 } } catch {}
try { if (Test-Path -LiteralPath $frontPath) { $frontText = Get-Content -LiteralPath $frontPath -Raw -Encoding UTF8 } } catch {}
$serverRuntimeOk = (Test-Path -LiteralPath $serverPath) -or (Test-Path -LiteralPath $serverPycPath)
$versionRegex = [regex]::Escape($Version)
$serverVersionOk = ($serverText -match ('APP_VERSION = "' + $versionRegex + '"') -and $serverText -match ('PACKAGE_REVISION = "' + $versionRegex + '"'))
if ($serverVersionOk -or ($serverRuntimeOk -and [string]::IsNullOrWhiteSpace($serverText))) { Add-Result "SCN-002" "SERVER" "PASS" "Server runtime" "$Version source or compiled runtime" $(if($serverVersionOk){"SOURCE_VERSION_OK"}else{"PYC_RUNTIME_OK"}) "" } else { Add-Result "SCN-002" "SERVER" "FAIL" "Server runtime" "$Version source or compiled runtime" "MISSING" "Check api/server.py or api/server.pyc." }
if ($frontText -match 'applyBacktestResult' -and $frontText -match 'exportBacktestPackage' -and $frontText -match 'isAdminLicenseRole') { Add-Result "SCN-003" "BACKTEST" "PASS" "Backtester admin tab" "Role-gated apply/export" "FOUND" "" } else { Add-Result "SCN-003" "BACKTEST" "FAIL" "Backtester admin tab" "Role-gated apply/export" "MISSING" "Check frontend bundle." }
$backupUploadPresent = ($frontText.Contains('uploadRestoreBackup') -or $frontText.Contains('backupUpload') -or $serverText.Contains('backup/upload-restore'))
if (-not $backupUploadPresent) { Add-Result "SCN-004" "BACKUP" "PASS" "External backup upload restore removed" "No UI/API surface" "REMOVED" "" } else { Add-Result "SCN-004" "BACKUP" "FAIL" "External backup upload restore removed" "No UI/API surface" "STILL_PRESENT" "Remove upload restore surface." }
$syncSourceOk = ($serverText -match 'run_all\.py' -and $serverText -match 'refresh_strategy_auxiliary_caches' -and $serverText -match 'operation_data_ready' -and $serverText -match 'append_operation_event')
if ($syncSourceOk -or ($serverRuntimeOk -and [string]::IsNullOrWhiteSpace($serverText))) { Add-Result "SCN-005" "SYNC" "PASS" "Data sync contract" "run_all, aux cache, readiness, timeline" $(if($syncSourceOk){"FOUND"}else{"PYC_RUNTIME_OK"}) "" } else { Add-Result "SCN-005" "SYNC" "FAIL" "Data sync contract" "run_all, aux cache, readiness, timeline" "MISSING" "Check /sync implementation." }
if ($frontText -match 'engineAdminOk') { Add-Result "SCN-006" "ENGINE" "PASS" "Engine import UI" "Admin gated file apply" "FOUND" "" } else { Add-Result "SCN-006" "ENGINE" "FAIL" "Engine import UI" "Admin gated file apply" "MISSING" "Check engine manager UI." }
$fail = @($Results | Where-Object { $_.level -eq "FAIL" }).Count
$warn = @($Results | Where-Object { $_.level -eq "WARN" }).Count
$pass = @($Results | Where-Object { $_.level -eq "PASS" }).Count
$stamp = Get-Date -Format "yyyyMMdd_HHmmss"
$reportRoot = Join-Path $AppDir "scenario_test_reports"
New-Item -ItemType Directory -Path $reportRoot -Force | Out-Null
$jsonPath = Join-Path $reportRoot ("AVS_SCENARIO_TEST_REPORT_{0}.json" -f $stamp)
$htmlPath = Join-Path $reportRoot ("AVS_SCENARIO_TEST_REPORT_{0}.html" -f $stamp)
$zipPath = Join-Path $reportRoot ("AVS_SCENARIO_TEST_REPORT_{0}.zip" -f $stamp)
$summary = [ordered]@{ tool="AVS Scenario Test Runner"; version=$Version; generated_at=(Get-Date).ToString("yyyy-MM-dd HH:mm:ss"); app_dir=$AppDir; base_url=$BaseUrl; pass=$pass; warn=$warn; fail=$fail; results=$Results }
$summary | ConvertTo-Json -Depth 10 | Set-Content -Path $jsonPath -Encoding UTF8
$rows = ($Results | ForEach-Object { "<tr class='$($_.level)'><td>$($_.id)</td><td>$($_.category)</td><td>$($_.level)</td><td>$(Escape-Html $_.name)</td><td>$(Escape-Html $_.expected)</td><td>$(Escape-Html $_.actual)</td><td>$(Escape-Html $_.action)</td></tr>" }) -join "`n"
$html = @"
<!doctype html><html><head><meta charset="utf-8"><title>AVS Scenario Test Report</title><style>body{font-family:Segoe UI,Arial,sans-serif;background:#101318;color:#e8ecf1;padding:28px}h1{font-size:24px}.summary{display:flex;gap:12px;margin:16px 0}.card{background:#171d26;border:1px solid #2b3442;border-radius:12px;padding:14px 18px}.FAIL{background:#3a1518}.WARN{background:#3b2c11}.PASS{background:#15351f}table{width:100%;border-collapse:collapse;background:#151a22;border-radius:12px;overflow:hidden}th,td{border-bottom:1px solid #2b3442;padding:9px 10px;text-align:left;font-size:13px}th{background:#202735}</style></head><body><h1>AVS Scenario Test Report v$Version</h1><div>Generated: $($summary.generated_at)</div><div>AVS_APP: $(Escape-Html $AppDir)</div><div class="summary"><div class="card FAIL">FAIL <b>$fail</b></div><div class="card WARN">WARN <b>$warn</b></div><div class="card PASS">PASS <b>$pass</b></div></div><table><thead><tr><th>ID</th><th>Category</th><th>Level</th><th>Item</th><th>Expected</th><th>Actual</th><th>Action</th></tr></thead><tbody>$rows</tbody></table></body></html>
"@
$html | Set-Content -Path $htmlPath -Encoding UTF8
Compress-Archive -Path $jsonPath,$htmlPath -DestinationPath $zipPath -Force
Write-Host "AVS Scenario Test complete." -ForegroundColor Green
Write-Host "Result: FAIL $fail / WARN $warn / PASS $pass" -ForegroundColor Green
Write-Host "Report folder: $reportRoot" -ForegroundColor Green
Write-Host "HTML: $htmlPath" -ForegroundColor Green
if ($OpenReport) { Start-Process $htmlPath }
if ($fail -gt 0) { exit 1 } elseif ($warn -gt 0) { exit 2 } else { exit 0 }















