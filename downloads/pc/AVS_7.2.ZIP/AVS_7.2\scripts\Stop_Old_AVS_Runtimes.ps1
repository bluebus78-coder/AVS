param(
    [Parameter(Mandatory = $true)]
    [string]$CurrentAppDir,
    [switch]$Quiet
)

$ErrorActionPreference = "Stop"

function Write-AvsRuntimeMessage([string]$Message) {
    if (-not $Quiet) { Write-Host $Message }
}

$CurrentAppDir = [System.IO.Path]::GetFullPath(
    [Environment]::ExpandEnvironmentVariables($CurrentAppDir.Trim().Trim('"'))
).TrimEnd('\')
if ((Split-Path -Leaf $CurrentAppDir) -ine "AVS_APP") {
    throw "CurrentAppDir must identify an AVS_APP directory: $CurrentAppDir"
}

$managedTokens = @(
    "scheduler_worker_safe.pyc",
    "scheduler_worker_safe.py",
    "scheduler_worker.pyc",
    "scheduler_worker.py",
    "auto_trade_worker.pyc",
    "auto_trade_worker.py",
    "avs_html_launcher.pyc",
    "avs_html_launcher.py",
    "run_all.pyc",
    "run_all.py",
    "-m uvicorn api.server:app"
)
$pidFiles = @(
    "runtime\scheduler_worker.pid",
    "scheduler_worker.pid",
    "runtime\auto_trade_worker.pid",
    "auto_trade_worker.pid",
    "runtime\html_server.pid"
)
$stopped = [System.Collections.Generic.List[object]]::new()
$oldAppDirs = [System.Collections.Generic.HashSet[string]]::new([System.StringComparer]::OrdinalIgnoreCase)
$failures = [System.Collections.Generic.List[string]]::new()

$processes = @(Get-CimInstance Win32_Process -ErrorAction Stop | Where-Object {
    $_.Name -in @("python.exe", "pythonw.exe") -and $_.CommandLine
})
foreach ($process in $processes) {
    $commandLine = [string]$process.CommandLine
    $managed = $false
    foreach ($token in $managedTokens) {
        if ($commandLine.IndexOf($token, [System.StringComparison]::OrdinalIgnoreCase) -ge 0) {
            $managed = $true
            break
        }
    }
    if (-not $managed) { continue }

    $match = [regex]::Match($commandLine, '(?i)(?<app>[A-Z]:\\[^"\r\n]*?\\AVS_APP)(?:\\|")')
    if (-not $match.Success) { continue }
    $candidateApp = [System.IO.Path]::GetFullPath($match.Groups["app"].Value).TrimEnd('\')
    if ($candidateApp.Equals($CurrentAppDir, [System.StringComparison]::OrdinalIgnoreCase)) { continue }
    if ((Split-Path -Leaf $candidateApp) -ine "AVS_APP") { continue }
    $installRootName = Split-Path -Leaf (Split-Path -Parent $candidateApp)
    if ($installRootName -notmatch '(?i)^AVS[_-]?\d') { continue }
    if (-not (Test-Path -LiteralPath $candidateApp -PathType Container)) { continue }

    $executablePath = [string]$process.ExecutablePath
    if (-not [string]::IsNullOrWhiteSpace($executablePath)) {
        $expectedPythonRoot = $candidateApp + "\runtime\python\"
        $resolvedExecutable = [System.IO.Path]::GetFullPath($executablePath)
        if (-not $resolvedExecutable.StartsWith($expectedPythonRoot, [System.StringComparison]::OrdinalIgnoreCase)) {
            continue
        }
    }

    try {
        Stop-Process -Id ([int]$process.ProcessId) -Force -ErrorAction Stop
        [void]$oldAppDirs.Add($candidateApp)
        $stopped.Add([ordered]@{
            pid = [int]$process.ProcessId
            app_dir = $candidateApp
            process = [string]$process.Name
        }) | Out-Null
        Write-AvsRuntimeMessage "Stopped obsolete AVS runtime: PID $($process.ProcessId) / $candidateApp"
    } catch {
        $failures.Add("PID $($process.ProcessId): $($_.Exception.Message)") | Out-Null
    }
}

Start-Sleep -Milliseconds 500
foreach ($oldAppDir in $oldAppDirs) {
    foreach ($relativePath in $pidFiles) {
        $pidPath = Join-Path $oldAppDir $relativePath
        if (-not (Test-Path -LiteralPath $pidPath -PathType Leaf)) { continue }
        $pidValue = 0
        [void][int]::TryParse((Get-Content -LiteralPath $pidPath -Raw -ErrorAction SilentlyContinue).Trim(), [ref]$pidValue)
        if ($pidValue -gt 0 -and (Get-Process -Id $pidValue -ErrorAction SilentlyContinue)) { continue }
        Remove-Item -LiteralPath $pidPath -Force -ErrorAction SilentlyContinue
    }
}

if ($failures.Count -gt 0) {
    throw "Obsolete AVS runtime cleanup failed: $($failures -join '; ')"
}

if (-not $Quiet) {
    [ordered]@{
        ok = $true
        current_app_dir = $CurrentAppDir
        stopped_count = $stopped.Count
        stopped = @($stopped)
    } | ConvertTo-Json -Depth 5
}
